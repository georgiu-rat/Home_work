//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        int age = 18;
        double height = 1.67;
        char firstLetter = 'Г';
        boolean isStudent  = true;
        System.out.println(age + "\n" + height + "\n" + firstLetter + "\n" + isStudent + "\n\n");

        byte temperature = -15;
        short currentYear = 2026;
        int cityPopulation = 1200000;
        long worldPopulation = 8100000000L;
        System.out.println(temperature +"\n" + currentYear + "\n" + cityPopulation + "\n" + worldPopulation + "\n\n");

        float alt = 1.23456789F;
        double tab = 1.1234567891011213;
        System.out.println(alt + "\n" + tab + "\n\n");

        char a1 = 'J';
        char a2 = 74;
        char a3 = '\u004A';
        System.out.println(a1 + "\n" + a2 + "\n" + a3 + "\n\n");

        boolean isreal = true;
        boolean istrue = true;
        boolean isgood = true;
        System.out.println(isreal + "\n" + istrue +"\n" + isgood + "\n\n");

        final double GRAVITI = 9.3;
        final double DAY = 24;
        final double YEAR = 365;
        System.out.println(GRAVITI + "\n" + DAY + "\n" + YEAR + "\n\n");

        int namber1 = 12;
        double namder2 = namber1;
        System.out.println(namber1 + "\n" + namder2+ "\n\n");

        double rin = 49.9;
        int fok = (int)rin;
        System.out.println(fok);
    }
}
