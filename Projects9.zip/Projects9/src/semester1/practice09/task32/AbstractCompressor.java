package semester1.practice09.task32;

public abstract class AbstractCompressor {
    protected final String algorithmName;
    public AbstractCompressor(String algorithmName) {
        this.algorithmName = (algorithmName == null || algorithmName.isBlank()) ? "StandardCompressor" : algorithmName;}
    public String getAlgorithmName() {
        return algorithmName;}
    public abstract String compress(String data);
    public abstract String decompress(String compressedData);
    @Override
    public String toString() {
        return String.format("Архіватор даних [Алгоритм: %s]", algorithmName);}
}
