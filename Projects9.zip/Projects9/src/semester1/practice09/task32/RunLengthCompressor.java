package semester1.practice09.task32;

public class RunLengthCompressor extends AbstractCompressor {
    public RunLengthCompressor() {
        super("RLE (Run-Length Encoding)");}
    @Override
    public String compress(String data) {
        if (data == null || data.isEmpty()) return "";
        StringBuilder compressed = new StringBuilder();
        int count = 1;
        for (int i = 0; i < data.length(); i++) {
            if (i + 1 < data.length() && data.charAt(i) == data.charAt(i + 1)) {
                count++;
            } else {
                compressed.append(data.charAt(i)).append(count);
                count = 1;}
        }return compressed.toString();}
    @Override
    public String decompress(String compressedData) {
        if (compressedData == null || compressedData.isEmpty()) return "";
        StringBuilder decompressed = new StringBuilder();
        for (int i = 0; i < compressedData.length(); i += 2) {
            char ch = compressedData.charAt(i);
            int count = Character.getNumericValue(compressedData.charAt(i + 1));
            for (int j = 0; j < count; j++) {
                decompressed.append(ch);}
        }return decompressed.toString();}
}
