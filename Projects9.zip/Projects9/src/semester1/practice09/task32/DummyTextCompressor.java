package semester1.practice09.task32;

public class DummyTextCompressor extends AbstractCompressor {
    public DummyTextCompressor() {
        super("DummyTextCompressor (Space Remover)");}
    @Override
    public String compress(String data) {
        if (data == null) return "";
        return data.replaceAll("\\s+", " ").trim().toLowerCase();}
    @Override
    public String decompress(String compressedData) {
        return (compressedData == null) ? "" : "[Розпаковано]: " + compressedData;}
}
