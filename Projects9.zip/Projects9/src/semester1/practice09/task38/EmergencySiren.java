package semester1.practice09.task38;

public class EmergencySiren {
    private boolean sounding;
    public EmergencySiren() {
        this.sounding = false;}
    public void activate() {
        this.sounding = true;
        System.out.println("УВАГА! Увімкнено аварійну сирену лабораторії! Рівень небезпеки критичний!");}
    public void deactivate() {
        this.sounding = false;
        System.out.println("Сирену вимкнено. Ситуація стабілізована.");}
    public boolean isSounding() {
        return sounding;}
    @Override
    public String toString() {
        return String.format("EmergencySiren{активна сирена=%s}", sounding ? "ТАК (ТРИВОГА)" : "Ні");}
}
