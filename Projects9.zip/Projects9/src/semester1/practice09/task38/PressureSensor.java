package semester1.practice09.task38;

import semester1.practice09.task31.AbstractSensor;

public class PressureSensor extends AbstractSensor {
    private double currentPressureBars;
    public PressureSensor(String sensorId, double currentPressureBars) {
        super(sensorId, "бар");
        this.currentPressureBars = currentPressureBars;}
    @Override
    public double readValue() {
        return currentPressureBars;}
    @Override
    public boolean isCritical(double threshold) {
        return this.currentPressureBars > threshold;}
    public void setPressure(double newPressure) {
        this.currentPressureBars = newPressure;}
}
