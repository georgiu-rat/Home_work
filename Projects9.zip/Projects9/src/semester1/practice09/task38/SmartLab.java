package semester1.practice09.task38;

import semester1.practice09.task31.AbstractSensor;

import java.util.Arrays;

public class SmartLab {
    private final String labName;
    private final EmergencySiren siren;
    private final AbstractSensor[] sensors;
    private int sensorCount;
    public SmartLab(String labName, int maxSensorsCapacity) {
        this.labName = (labName == null || labName.isBlank()) ? "Центральна Лабораторія" : labName;
        this.siren = new EmergencySiren();
        int capacity = Math.max(1, maxSensorsCapacity);
        this.sensors = new AbstractSensor[capacity];
        this.sensorCount = 0;}
    public boolean addSensor(AbstractSensor sensor) {
        if (sensor == null) return false;
        if (sensorCount >= sensors.length) {
            System.out.println("Досягнуто ліміт кількості датчиків у лабораторії.");
            return false;}
        sensors[sensorCount++] = sensor;
        return true;}
    public void runDiagnostics() {
        System.out.printf("[Запуск діагностики для лабораторії '%s']...\n", labName);
        boolean emergencyDetected = false;
        double threshold = 50.0;
        for (int i = 0; i < sensorCount; i++) {
            AbstractSensor sensor = sensors[i];
            System.out.println("  - Перевірка: " + sensor);
            if (sensor.isCritical(threshold)) {
                System.out.printf("З А С Т Р Е Ж Е Н Н Я! Датчик [%s] зафіксував критичний показник вище порогового (%.1f)!\n",
                        sensor.getSensorId(), threshold);
                emergencyDetected = true;}
        }
        if (emergencyDetected) {
            siren.activate();
        } else {
            if (siren.isSounding()) {
                siren.deactivate();
            } else {
                System.out.println("Усі показники в нормі. Системи працюють стабільно.\n");}
        }
    }
    public AbstractSensor[] getSensors() {
        return Arrays.copyOf(sensors, sensorCount);}
    @Override
    public String toString() {
        return String.format("SmartLab{назва='%s', датчиків=%d, %s}", labName, sensorCount, siren);}
}
