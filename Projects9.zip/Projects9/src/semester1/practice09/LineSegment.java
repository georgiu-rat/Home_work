package semester1.practice09;

public class LineSegment {
    private final Point2D start;
    private final Point2D end;
    public LineSegment(Point2D start, Point2D end) {
        if (start == null) {
            this.start = new Point2D(0.0, 0.0);
        } else {
            this.start = new Point2D(start.getX(), start.getY());}
        if (end == null) {
            this.end = new Point2D(0.0, 0.0);
        } else {
            this.end = new Point2D(end.getX(), end.getY());}
    }
    public double getLength() {
        return start.distanceTo(end);}
    public Point2D getMidpoint() {
        double midX = (start.getX() + end.getX()) / 2.0;
        double midY = (start.getY() + end.getY()) / 2.0;
        return new Point2D(midX, midY);}public Point2D getStart() {
        return new Point2D(start.getX(), start.getY());}
    public Point2D getEnd() {
        return new Point2D(end.getX(), end.getY());}
    @Override
    public String toString() {
        return String.format("LineSegment{start=%s, end=%s, довжина=%.2f}", start, end, getLength());}
}
