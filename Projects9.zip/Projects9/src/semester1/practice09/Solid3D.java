package semester1.practice09;

public abstract class Solid3D {
    public abstract double getVolume();
    public abstract double getSurfaceArea();
    public final double calculateMass(double density) {
        return getVolume() * Math.max(0.0, density);}
    @Override
    public String toString() {
        return String.format("3D-тіло [Об'єм = %.2f, Площа поверхні = %.2f]",
                getVolume(), getSurfaceArea());}}
