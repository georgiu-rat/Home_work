package semester1.practice09;

public class GeometricProgression extends AbstractSequence {
    private final double commonRatio; // знаменник прогресії (q)
    public GeometricProgression(double firstElement, double commonRatio) {
        super(firstElement);
        this.commonRatio = commonRatio;}
    @Override
    public double getElement(int n) {
        int index = Math.max(1, n);
        return firstElement * Math.pow(commonRatio, index - 1);}
    @Override
    public String toString() {
        return String.format("GeometricProgression{перший член=%.1f, знаменник=%.1f} — %s",
                firstElement, commonRatio, super.toString());}
}
