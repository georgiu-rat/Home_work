package semester1.practice09;

public class IbanPaymentTransaction extends AbstractTransaction {
    private final String iban;
    private final String recipientName;
    public IbanPaymentTransaction(double amount, String iban, String recipientName) {
        super(amount);
        this.iban = (iban == null || iban.isBlank()) ? "UA000000000000000000000000000" : iban;
        this.recipientName = (recipientName == null || recipientName.isBlank()) ? "Отримувач" : recipientName;}
    @Override
    public boolean execute() {
        if (executed) return false;
        System.out.printf("Платіж за IBAN [%s] на користь '%s': успішно переведено %.2f грн.\n",
                iban, recipientName, amount);
        executed = true;
        return true;}
    @Override
    public String toString() {
        return String.format("IbanPayment{отримувач='%s', IBAN='%s', %s}", recipientName, iban, super.toString());}
}
