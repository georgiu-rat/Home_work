package semester1.practice09.task34;

public class PlasmaEngine extends AbstractEngine {
    private final double magneticConfinementPowerMegawatts;
    public PlasmaEngine(double thrustKilonewtons, double magneticConfinementPowerMegawatts) {
        super("Плазмовий двигун (VASIMR)", thrustKilonewtons);
        this.magneticConfinementPowerMegawatts = Math.max(10.0, magneticConfinementPowerMegawatts);}
    @Override
    public double calculateAcceleration(double shipMassKg) {
        if (shipMassKg <= 0) return 0.0;
        return (thrustKilonewtons * 1000.0) / shipMassKg;}
    @Override
    public double calculateFuelConsumptionRate() {
        return magneticConfinementPowerMegawatts * 0.15;}
        @Override
    public String toString() {
        return String.format("PlasmaEngine{потужність утримання=%.1f МВт, %s}",
                magneticConfinementPowerMegawatts, super.toString());}
}