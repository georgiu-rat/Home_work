package semester1.practice09.task34;

public class IonEngine extends AbstractEngine {
    private final double specificImpulse;
    public IonEngine(double thrustKilonewtons, double specificImpulse) {
        super("Іонний двигун", thrustKilonewtons);
        this.specificImpulse = Math.max(1000.0, specificImpulse);}
    @Override
    public double calculateAcceleration(double shipMassKg) {
        if (shipMassKg <= 0) return 0.0;
        return (thrustKilonewtons * 1000.0) / shipMassKg;}
    @Override
    public double calculateFuelConsumptionRate() {
        return 0.05;}
    @Override
    public String toString() {
        return String.format("IonEngine{питомий імпульс=%.1f с, %s}", specificImpulse, super.toString());}
}
