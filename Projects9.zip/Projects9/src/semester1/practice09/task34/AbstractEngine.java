package semester1.practice09.task34;

public abstract class AbstractEngine {
    protected final String engineType;
    protected final double thrustKilonewtons;
    public AbstractEngine(String engineType, double thrustKilonewtons) {
        this.engineType = (engineType == null || engineType.isBlank()) ? "Стандартний двигун" : engineType;
        this.thrustKilonewtons = Math.max(1.0, thrustKilonewtons);}
    public String getEngineType() {
        return engineType;}
    public abstract double calculateAcceleration(double shipMassKg);
    public abstract double calculateFuelConsumptionRate();
    @Override
    public String toString() {
        return String.format("Двигун [%s, Тяга: %.1f кН]", engineType, thrustKilonewtons);}
}
