package semester1.practice09.task37;

public abstract class AbstractHeroUnit {
    protected final String name;
    protected int hp;
    public AbstractHeroUnit(String name, int hp) {
        this.name = (name == null || name.isBlank()) ? "Невідомий герой" : name;
        this.hp = Math.max(1, hp);}
    public String getName() {
        return name;}
    public int getHp() {
        return hp;}
    public abstract int getCombatPower();
    public abstract String getRole();
    @Override
    public String toString() {
        return String.format("Герой [%s] (Роль: %s) — HP: %d, Бойова сила: %d",
                name, getRole(), hp, getCombatPower());}
}
