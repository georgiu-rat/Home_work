package semester1.practice09.task37;

public class TankWarrior extends AbstractHeroUnit {
    private final int armorRating;
    public TankWarrior(String name, int hp, int armorRating) {
        super(name, hp);
        this.armorRating = Math.max(10, armorRating);}
    @Override
    public int getCombatPower() {
        return (hp * 2) + (armorRating * 3);}
    @Override
    public String getRole() {
        return "Tank";}
    @Override
    public String toString() {
        return String.format("TankWarrior{броня=%d, %s}", armorRating, super.toString());}
}
