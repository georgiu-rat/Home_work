package semester1.practice09.task37;

import java.util.Arrays;

public class RaidParty {
    private final String guildName;
    private final AbstractHeroUnit[] members;
    private int memberCount;
    public RaidParty(String guildName, int maxCapacity) {
        this.guildName = (guildName == null || guildName.isBlank()) ? "Гільдія" : guildName;
        int capacity = Math.max(1, maxCapacity);
        this.members = new AbstractHeroUnit[capacity];
        this.memberCount = 0;}
    public boolean addHero(AbstractHeroUnit hero) {
        if (hero == null) return false;
        if (memberCount >= members.length) {
            System.out.println("⚠️ У загін більше не можна набрати героїв (досягнуто ліміт).");
            return false;}
        members[memberCount++] = hero;
        return true;}
    public int getTotalCombatPower() {
        int total = 0;
        for (int i = 0; i < memberCount; i++) {
            total += members[i].getCombatPower();}
        return total;}
    public boolean hasTank() {
        for (int i = 0; i < memberCount; i++) {
            if ("Tank".equalsIgnoreCase(members[i].getRole())) {
                return true;}}
        return false;}
    public boolean isReadyForRaid(int dungeonRequiredPower) {
        if (!hasTank()) {
            System.out.println("Загін не готовий до рейду: немає жодного героя з роллю 'Tank'!");
            return false;}
        int totalPower = getTotalCombatPower();
        if (totalPower < dungeonRequiredPower) {
            System.out.printf("Загін недостатньо сильний! Сумарна сила %d менша за вимогу підземелля (%d).\n",
                    totalPower, dungeonRequiredPower);
            return false;}
        System.out.println("Загін повністю укомплектований і готовий до успішного рейду!");
        return true;}
    public AbstractHeroUnit[] getMembers() {
        return Arrays.copyOf(members, memberCount);}
    @Override
    public String toString() {
        return String.format("RaidParty{гільдія='%s', героїв=%d, сумарна бойова сила=%d, є тан=%s}",
                guildName, memberCount, getTotalCombatPower(), (hasTank() ? "Так" : "Ні"));}
}
