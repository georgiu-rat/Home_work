package semester1.practice09.task37;

public class ArcaneMage extends AbstractHeroUnit {
    private final int spellPower;
    public ArcaneMage(String name, int hp, int spellPower) {
        super(name, hp);
        this.spellPower = Math.max(20, spellPower);}
    @Override
    public int getCombatPower() {
        return hp + (spellPower * 4);}
    @Override
    public String getRole() {
        return "Mage";}
    @Override
    public String toString() {
        return String.format("ArcaneMage{сила заклинань=%d, %s}", spellPower, super.toString());}
}
