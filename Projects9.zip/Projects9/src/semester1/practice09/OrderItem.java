package semester1.practice09;

public class OrderItem {
    private final String productName;
    private final double unitPrice;
    private int quantity;
    public OrderItem(String productName, double unitPrice, int quantity) {
        this.productName = (productName == null || productName.isBlank()) ? "Товар" : productName;
        this.unitPrice = Math.max(0.0, unitPrice);
        this.quantity = Math.max(1, quantity);}
    public void addQuantity(int amount) {
        if (amount > 0) {
            this.quantity += amount;}
    }
    public double getItemTotal() {
        return unitPrice * quantity;}
    public String getProductName() {
        return productName;}
    public int getQuantity() {
        return quantity;}
    @Override
    public String toString() {
        return String.format("%-15s | %.2f грн x %d шт. = %.2f грн",
                productName, unitPrice, quantity, getItemTotal());}
}
