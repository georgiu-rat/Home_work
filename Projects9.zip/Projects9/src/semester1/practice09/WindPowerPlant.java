package semester1.practice09;

public class WindPowerPlant extends AbstractPowerPlant {
    private final double windSpeedMs;
    public WindPowerPlant(String stationName, double baseCapacityMw, double windSpeedMs) {
        super(stationName, baseCapacityMw);
        this.windSpeedMs = Math.max(0.0, windSpeedMs);}
    @Override
    public double generateMegawatts() {
        if (windSpeedMs < 3.0 || windSpeedMs > 25.0) {
            return 0.0;}
        double efficiency = Math.min(1.0, windSpeedMs / 12.0);
        return baseCapacityMw * efficiency;}
    @Override
    public String toString() {
        return String.format("WindPowerPlant{вітер=%.1f м/с, %s}",
                windSpeedMs, super.toString());}}
