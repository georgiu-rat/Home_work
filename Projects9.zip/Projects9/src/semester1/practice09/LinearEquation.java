package semester1.practice09;

public class LinearEquation {
    private final double a;
    private final double b;
    private final double c;
    public LinearEquation(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;}
    public boolean isSatisfiedBy(double x, double y) {
        double leftSide = a * x + b * y;
        return Math.abs(leftSide - c) < 1e-6;}
    @Override
    public String toString() {
        return String.format("%.1fx + %.1fy = %.1f", a, b, c);}
}
