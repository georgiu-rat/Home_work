package semester1.practice09;

import java.util.Arrays;

public class LabMeasurement {
    private final String experimentName;
    private final double[] samples;

    public LabMeasurement(String experimentName,double[] samples){
        this.experimentName = (experimentName == null || experimentName.isBlank())
                ? "Невідомий експеримент"
                : experimentName;
        if (samples == null) {
            this.samples = new double[0];
        } else {
            this.samples = Arrays.copyOf(samples, samples.length);}}
    public String getExperimentName() {
        return experimentName;}

    public double[] getSamples() {
        return Arrays.copyOf(this.samples, this.samples.length);}

    @Override
    public String toString() {
        return String.format("LabMeasurement{name='%s', samples=%s}",
                experimentName, Arrays.toString(samples));}
}
