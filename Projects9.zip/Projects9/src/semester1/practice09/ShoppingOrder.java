package semester1.practice09;

public class ShoppingOrder {
    private final OrderItem[] items; // КОМПОЗИЦІЯ: Замовлення має масив товарів
    private int itemCount;
    public ShoppingOrder(int capacity) {
        int cap = Math.max(1, capacity);
        this.items = new OrderItem[cap];
        this.itemCount = 0;}
    public void addItem(String name, double price, int qty) {
        if (name == null || name.isBlank()) return;
        for (int i = 0; i < itemCount; i++) {
            if (items[i].getProductName().equalsIgnoreCase(name)) {
                items[i].addQuantity(qty);
                return;}
        }
        if (itemCount < items.length) {
            items[itemCount++] = new OrderItem(name, price, qty);
        } else {
            System.out.println("⚠️ Попередження: Кошик заповнено, новий товар не помістився!");}
    }
    public double calculateGrandTotal() {
        double total = 0.0;
        for (int i = 0; i < itemCount; i++) {
            total += items[i].getItemTotal();}
        return total;}
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("\n--- ФІСКАЛЬНИЙ ЧЕК ЗАМОВЛЕННЯ ---\n");
        for (int i = 0; i < itemCount; i++) {
            sb.append(items[i]).append("\n");}
        sb.append("------------------------------------\n");
        sb.append(String.format("ЗАГАЛЬНА СУМА ДО СПЛАТИ: %.2f грн\n", calculateGrandTotal()));
        return sb.toString();}
}
