package semester1.practice09.task39;

import java.util.Arrays;

public class SignalProcessor {
    private final AbstractFilter[] pipeline;
    private int filterCount;
    public SignalProcessor(int maxFiltersCapacity) {
        int capacity = Math.max(1, maxFiltersCapacity);
        this.pipeline = new AbstractFilter[capacity];
        this.filterCount = 0;}
    public boolean addFilter(AbstractFilter filter) {
        if (filter == null) return false;
        if (filterCount >= pipeline.length) {
            System.out.println("⚠️ Конвеєр заповнено, новий фільтр неможливо додати.");
            return false;}
        pipeline[filterCount++] = filter;
        return true;}
    public double[] processSignal(double[] inputSignal) {
        if (inputSignal == null) return new double[0];
        double[] currentSignal = Arrays.copyOf(inputSignal, inputSignal.length);
        for (int i = 0; i < filterCount; i++) {
            AbstractFilter filter = pipeline[i];
            for (int j = 0; j < currentSignal.length; j++) {
                currentSignal[j] = filter.processSample(currentSignal[j]);}
        }
        return currentSignal;}
    @Override
    public String toString() {
        return String.format("SignalProcessor{активних фільтрів у конвеєрі=%d}", filterCount);}
}
