package semester1.practice09.task39;

public abstract class AbstractFilter {
    protected final String filterName;
    public AbstractFilter(String filterName) {
        this.filterName = (filterName == null || filterName.isBlank()) ? "StandardFilter" : filterName;}
    public String getFilterName() {
        return filterName;}
    public abstract double processSample(double x);
    @Override
    public String toString() {
        return String.format("Фільтр [%s]", filterName);}
}
