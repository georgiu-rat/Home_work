package semester1.practice09.task39;

public class ClippingFilter extends AbstractFilter {
    private final double threshold;
    public ClippingFilter(double threshold) {
        super("Clipping (Поріг: ±" + threshold + ")");
        this.threshold = Math.abs(threshold);}
    @Override
    public double processSample(double x) {
        return Math.max(-threshold, Math.min(threshold, x));}
}
