package semester1.practice09.task39;

public class AmplifierFilter extends AbstractFilter {
    private final double gain;
    public AmplifierFilter(double gain) {
        super("Amplifier (Коефіцієнт: " + gain + ")");
        this.gain = gain;}
    @Override
    public double processSample(double x) {
        return x * gain;}
}
