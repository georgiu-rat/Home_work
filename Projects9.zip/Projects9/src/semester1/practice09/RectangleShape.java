package semester1.practice09;

public class RectangleShape extends AbstractShape {
    private final double width;
    private final double height;
    public RectangleShape(String color, double width, double height) {
        super(color);
        this.width = Math.max(0.1, width);
        this.height = Math.max(0.1, height);}
    @Override
    public double getArea() {
        return width * height;}
    @Override
    public double getPerimeter() {
        return 2 * (width + height);}
    @Override
    public String toString() {
        return String.format("Rectangle{ширина=%.2f, висота=%.2f, %s}", width, height, super.toString());}
}