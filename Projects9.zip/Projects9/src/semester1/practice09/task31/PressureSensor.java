package semester1.practice09.task31;

public class PressureSensor extends AbstractSensor {
    private final double currentPressureBar;
    public PressureSensor(String sensorId, double currentPressureBar) {
        super(sensorId, "бар");
        this.currentPressureBar = Math.max(0.0, currentPressureBar);}
    @Override
    public double readValue() {
        return currentPressureBar;}
    @Override
    public boolean isCritical(double threshold) {
        return currentPressureBar > threshold || currentPressureBar < 1.0;}
    @Override
    public String toString() {
        return String.format("PressureSensor{%s}", super.toString());}
}
