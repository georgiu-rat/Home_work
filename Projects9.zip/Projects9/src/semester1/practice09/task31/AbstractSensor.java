package semester1.practice09.task31;

public abstract class AbstractSensor {
    protected final String sensorId;
    protected final String unit;
    public AbstractSensor(String sensorId, String unit) {
        this.sensorId = (sensorId == null || sensorId.isBlank()) ? "SENSOR-001" : sensorId;
        this.unit = (unit == null || unit.isBlank()) ? "од." : unit;}
    public String getSensorId() {
        return sensorId;}
    public abstract double readValue();
    public abstract boolean isCritical(double threshold);
    @Override
    public String toString() {
        return String.format("Датчик [%s] — Поточне значення: %.2f %s",
                sensorId, readValue(), unit);}
}
