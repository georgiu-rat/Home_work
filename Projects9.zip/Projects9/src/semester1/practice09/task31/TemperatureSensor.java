package semester1.practice09.task31;


public class TemperatureSensor extends AbstractSensor {
    private final double currentTemperature;
    public TemperatureSensor(String sensorId, double currentTemperature) {
        super(sensorId, "°C");
        this.currentTemperature = currentTemperature;}
    @Override
    public double readValue() {
        return currentTemperature;}
    @Override
    public boolean isCritical(double threshold) {
        return currentTemperature > threshold;}
    @Override
    public String toString() {
        return String.format("TemperatureSensor{%s}", super.toString());}
}
