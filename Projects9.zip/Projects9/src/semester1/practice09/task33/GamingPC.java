package semester1.practice09.task33;

public class GamingPC extends AbstractDesktopPC {
    private final String gpu;
    private final boolean liquidCooling;
    public GamingPC(String cpu, int ramGb, double basePrice, String gpu, boolean liquidCooling) {
        super(cpu, ramGb, basePrice);
        this.gpu = (gpu == null || gpu.isBlank()) ? "NVIDIA RTX 4060" : gpu;
        this.liquidCooling = liquidCooling;}
    @Override
    public double calculateTotalPrice() {
        double gpuCost = 25000.0;
        double coolingCost = liquidCooling ? 5000.0 : 1500.0;
        return basePrice + gpuCost + coolingCost;}
    @Override
    public String toString() {
        return String.format("GamingPC{відеокарта='%s', охолодження=%s, %s}",
                gpu, (liquidCooling ? "Рідинне" : "Повітряне"), super.toString());}
}
