package semester1.practice09.task33;

public abstract class AbstractDesktopPC {
    protected final String cpu;
    protected final int ramGb;
    protected final double basePrice;
    public AbstractDesktopPC(String cpu, int ramGb, double basePrice) {
        this.cpu = (cpu == null || cpu.isBlank()) ? "Intel Core i5" : cpu;
        this.ramGb = Math.max(4, ramGb);
        this.basePrice = Math.max(0.0, basePrice);}
    public String getCpu() {
        return cpu;}
    public int getRamGb() {
        return ramGb;}
    public abstract double calculateTotalPrice();
    @Override
    public String toString() {
        return String.format("ПК [Процесор: %s, ОЗП: %d GB] — Загальна вартість: %.2f грн",
                cpu, ramGb, calculateTotalPrice());}
}
