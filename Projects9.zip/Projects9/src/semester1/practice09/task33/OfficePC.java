package semester1.practice09.task33;

public class OfficePC extends AbstractDesktopPC {
    private final boolean includesMonitor;
    public OfficePC(String cpu, int ramGb, double basePrice, boolean includesMonitor) {
        super(cpu, ramGb, basePrice);
        this.includesMonitor = includesMonitor;}
    @Override
    public double calculateTotalPrice() {
        double monitorCost = includesMonitor ? 4500.0 : 0.0;
        return basePrice + monitorCost;}
    @Override
    public String toString() {
        return String.format("OfficePC{монітор у комплекті=%s, %s}",
                (includesMonitor ? "Так" : "Ні"), super.toString());}
}
