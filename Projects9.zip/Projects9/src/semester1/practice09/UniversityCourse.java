package semester1.practice09;

public class UniversityCourse {
    private final String courseTitle;
    private final CourseModule[] modules;
    private int moduleCount;
    public UniversityCourse(String courseTitle, int capacity) {
        this.courseTitle = (courseTitle == null || courseTitle.isBlank()) ? "Курс" : courseTitle;
        int cap = Math.max(1, capacity);
        this.modules = new CourseModule[cap];
        this.moduleCount = 0;}
    public boolean addModule(CourseModule module) {
        if (module == null) return false;
        if (moduleCount < modules.length) {
            modules[moduleCount++] = module;
            return true;}
        System.out.println("⚠️ Попередження: У курсі '" + courseTitle + "' досягнуто максимальну кількість модулів!");
        return false;}
    public int getTotalHours() {
        int total = 0;
        for (int i = 0; i < moduleCount; i++) {
            total += modules[i].getTotalHours();}
        return total;}
    public double calculateEctsCredits() {
        return getTotalHours() / 30.0;}
    public boolean validateTotalScore() {
        double totalScore = 0.0;
        for (int i = 0; i < moduleCount; i++) {
            totalScore += modules[i].getMaxScore();}
        return Math.abs(totalScore - 100.0) < 1e-6;}
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(String.format("UniversityCourse{назва='%s', кредитів ЄКТС=%.1f}:\n",
                courseTitle, calculateEctsCredits()));
        for (int i = 0; i < moduleCount; i++) {
            sb.append("  - ").append(modules[i]).append("\n");}
        sb.append(String.format("  Валідність суми балів (100): %s", validateTotalScore() ? "Так" : "Ні (сума не дорівнює 100)"));
        return sb.toString();}
}
