package semester1.practice09;

public class SphereSolid extends Solid3D {
    private final double radius;
    public SphereSolid(double radius) {
        this.radius = Math.max(0.1, radius);}
    @Override
    public double getVolume() {
        return (4.0 / 3.0) * Math.PI * Math.pow(radius, 3);}

    @Override
    public double getSurfaceArea() {
        return 4.0 * Math.PI * radius * radius;}
    @Override
    public String toString() {
        return String.format("SphereSolid{радіус=%.2f, %s}", radius, super.toString());}
}
