package semester1.practice09;

public class ParcelOrder {
    private final String orderId;
    private final double weightKg;
    private DeliveryAddress destination;
    private boolean shipped;
    public ParcelOrder(String orderId, double weightKg, DeliveryAddress destination) {
        this.orderId = (orderId == null || orderId.isBlank()) ? "ORD-0000" : orderId;
        this.weightKg = Math.max(0.1, weightKg);
        this.destination = (destination != null) ? destination : new DeliveryAddress("Київ", "Хрещатик", 1);
        this.shipped = false;}
    public boolean changeDestination(DeliveryAddress newAddress) {
        if (shipped) {
            System.out.printf("   Замовлення %s вже відправлено! Змінити адресу неможливо.\n", orderId);
            return false;}
        if (newAddress == null) {
            System.out.println("  Помилка: Нова адреса не може бути порожньою.");
            return false;}
        this.destination = newAddress;
        System.out.printf("  Адресу доставки для замовлення %s успішно оновлено.\n", orderId);
        return true;}
    public void markAsShipped() {
        this.shipped = true;
        System.out.printf("  Замовлення %s передано в службу доставки (статус: відправлено).\n", orderId);}
    public boolean isShipped() {
        return shipped;}
    @Override
    public String toString() {
        return String.format("ParcelOrder{№='%s', вага=%.2f кг, відправлено=%s, адреса=[%s]}",
                orderId, weightKg, shipped, destination);}
}
