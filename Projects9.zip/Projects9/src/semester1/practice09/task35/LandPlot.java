package semester1.practice09.task35;

import semester1.practice09.AbstractShape;

import java.util.Arrays;

public class LandPlot {
    private final double totalPlotAreaM2;
    private final AbstractShape[] structures;
    private int count;
    public LandPlot(double totalPlotAreaM2, int maxStructuresCapacity) {
        this.totalPlotAreaM2 = Math.max(10.0, totalPlotAreaM2);
        int capacity = Math.max(1, maxStructuresCapacity);
        this.structures = new AbstractShape[capacity];
        this.count = 0;}
    public boolean addStructure(AbstractShape shape) {
        if (shape == null) {
            System.out.println("⚠️ Неможливо додати порожню споруду (null).");
            return false;}
        if (count >= structures.length) {
            System.out.println("⚠️ На ділянці більше немає місця для нових об'єктів (досягнуто ліміт масиву).");
            return false;}
        double currentBuiltArea = getOccupiedBuiltArea();
        double newBuildingArea = shape.getArea();
        double maxAllowedBuiltArea = totalPlotAreaM2 * 0.60; // Ліміт 60%
        if (currentBuiltArea + newBuildingArea > maxAllowedBuiltArea) {
            System.out.printf("Відмова у будівництві! Перевищено ліміт 60%% забудови ділянки (%.2f м² з %.2f м² дозволених).\n",
                    (currentBuiltArea + newBuildingArea), maxAllowedBuiltArea);
            return false;}
        structures[count++] = shape;
        System.out.printf("Успішно зведено споруду: %s (Площа: %.2f м²)\n", shape.getClass().getSimpleName(), newBuildingArea);
        return true;}
    public double getOccupiedBuiltArea() {
        double totalArea = 0.0;
        for (int i = 0; i < count; i++) {
            totalArea += structures[i].getArea();}
        return totalArea;}
    public double getFreeGreenArea() {
        return totalPlotAreaM2 - getOccupiedBuiltArea();}
    public AbstractShape[] getStructures() {
        return Arrays.copyOf(structures, count);}
    @Override
    public String toString() {
        return String.format("LandPlot{Загальна площа=%.2f м², Забудовано=%.2f м², Вільно під газон=%.2f м², Кількість споруд=%d}",
                totalPlotAreaM2, getOccupiedBuiltArea(), getFreeGreenArea(), count);}
}
