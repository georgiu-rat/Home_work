package semester1.practice09;

public class HourlyEmployee extends AbstractEmployee {
    private final double hourlyRate;
    private final int hoursWorked;
    public HourlyEmployee(String fullName, String position, double hourlyRate, int hoursWorked) {
        super(fullName, position);
        this.hourlyRate = Math.max(0.0, hourlyRate);
        this.hoursWorked = Math.max(0, hoursWorked);}
    @Override
    public double calculateMonthlyPay() {
        return hourlyRate * hoursWorked;}
}
