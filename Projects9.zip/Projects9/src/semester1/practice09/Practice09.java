package semester1.practice09;

import semester1.practice09.task16.ClimateController;
import semester1.practice09.task31.AbstractSensor;
import semester1.practice09.task31.PressureSensor;
import semester1.practice09.task31.TemperatureSensor;
import semester1.practice09.task32.AbstractCompressor;
import semester1.practice09.task32.DummyTextCompressor;
import semester1.practice09.task32.RunLengthCompressor;
import semester1.practice09.task33.AbstractDesktopPC;
import semester1.practice09.task33.GamingPC;
import semester1.practice09.task33.OfficePC;
import semester1.practice09.task34.AbstractEngine;
import semester1.practice09.task34.IonEngine;
import semester1.practice09.task34.PlasmaEngine;
import semester1.practice09.task35.LandPlot;
import semester1.practice09.task36.AbstractAsset;
import semester1.practice09.task36.DividendStock;
import semester1.practice09.task36.GovernmentBond;
import semester1.practice09.task36.InvestmentPortfolio;
import semester1.practice09.task37.AbstractHeroUnit;
import semester1.practice09.task37.ArcaneMage;
import semester1.practice09.task37.RaidParty;
import semester1.practice09.task37.TankWarrior;
import semester1.practice09.task38.SmartLab;
import semester1.practice09.task39.AmplifierFilter;
import semester1.practice09.task39.ClippingFilter;
import semester1.practice09.task39.SignalProcessor;

import java.util.Arrays;

public class Practice09 {
    public static void main(String[] args) {
        System.out.println("\n\nЗавдання 1: Незмінна географічна координата (ImmutableGeoPoint)");
        ImmutableGeoPoint point1 = new ImmutableGeoPoint(150.0, -200.0);
        System.out.println("Точка 1 після валідації меж: " + point1);
        ImmutableGeoPoint point2 = new ImmutableGeoPoint(50.4501, 30.5234); // Наприклад, Київ
        System.out.println("Початкова точка 2: " + point2);
        ImmutableGeoPoint shiftedPoint = point2.shift(1.5, -2.0);
        System.out.println("Зміщена точка (новий об'єкт): " + shiftedPoint);
        System.out.println("Оригінальна точка 2 не змінилася: " + point2);

        System.out.println("\n\nЗавдання 2: Захисне копіювання масиву результатів експерименту (LabMeasurement)");
        double[] externalData = {12.5, 14.2, 9.8};
        LabMeasurement measurement = new LabMeasurement("Спектрометрія", externalData);
        System.out.println("Початковий стан об'єкта: " + measurement);
        externalData[0] = 999.9;
        System.out.println("Після зміни зовнішнього externalData[0]: " + measurement);
        double[] leakedData = measurement.getSamples();
        leakedData[1] = -550.0;
        System.out.println("Після зміни leakedData[1] з геттера: " + measurement);

        System.out.println("\n\nЗавдання 3: Криптографічний гаманець без відкритих сеттерів (CryptoVault)");
        CryptoVault vault = new CryptoVault("bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh", "correct horse battery staple", 1.5);
        System.out.println("Створений гаманець: " + vault);
        vault.sendBtc(0.5, "1RecipientAddress");
        boolean unlockedWrong = vault.unlock("wrong phrase");
        System.out.println("Розблокування невірною фразою успішне? " + unlockedWrong);
        boolean unlockedCorrect = vault.unlock("correct horse battery staple");
        System.out.println("Розблокування правильною фразою успішне? " + unlockedCorrect);
        vault.sendBtc(0.5, "1RecipientAddress");
        System.out.println("Стан гаманця після переказу: " + vault);
        vault.lock();
        System.out.println("Гаманець заблоковано? " + vault.isLocked());

        System.out.println("\n\nЗавдання 4: Математичний інтервал із самовідновлюваним інваріантом (ClosedInterval)");
        ClosedInterval interval1 = new ClosedInterval(10.0, 2.0);
        System.out.println("Інтервал 1 (автозаміна start/end): " + interval1);
        ClosedInterval interval2 = new ClosedInterval(8.0, 15.0);
        System.out.println("Інтервал 2: " + interval2);
        System.out.println("Інтервали перетинаються? " + interval1.overlaps(interval2));
        ClosedInterval interval3 = new ClosedInterval(20.0, 30.0);
        System.out.println("Інтервал 1 та 3 перетинаються? " + interval1.overlaps(interval3));

        System.out.println("\n\nЗавдання 5: Інкапсульований RGB-колір (RgbColor) із перевіркою каналів");
        RgbColor invalidColor = new RgbColor(300, -50, 128);
        System.out.println("Колір після валідації: " + invalidColor);
        RgbColor redColor = new RgbColor(255, 0, 0);
        RgbColor blueColor = new RgbColor(0, 0, 255);
        System.out.println("Червоний: " + redColor);
        RgbColor invertedRed = redColor.invert();
        System.out.println("Інвертований червоний: " + invertedRed);
        RgbColor mixed = redColor.mixWith(blueColor);
        System.out.println("Змішування червоного і синього: " + mixed);

        System.out.println("\nЗавдання 6: Банківський сейф із лічильником спроб та часовим блокуванням (HighSecuritySafe)");
        HighSecuritySafe safe = new HighSecuritySafe(7777, 10000.0);
        System.out.println("Початковий стан: " + safe);
        safe.putCash(1111, 500.0);
        safe.putCash(2222, 500.0);
        safe.putCash(3333, 500.0);
        safe.takeCash(7777, 1000.0);
        safe.takeCash(7777, 1000.0);

        System.out.println("\n\nЗавдання 7: Інкапсульований многочлен із захищеним масивом коефіцієнтів (EncapsulatedPolynomial)");
        double[] inputCoeffs = {2.0, 3.0, 1.5};
        EncapsulatedPolynomial poly = new EncapsulatedPolynomial(inputCoeffs);
        System.out.println("Многочлен: " + poly);
        System.out.println("Степінь многочлена: " + poly.getDegree());
        double result = poly.evaluate(2.0);
        System.out.println("Значення P(2.0) = " + result);
        inputCoeffs[0] = 999.0;
        System.out.println("Після зміни зовнішнього масиву, многочлен не змінився: " + poly);

        System.out.println("\n\nЗавдання 8: Медична картка пацієнта із захистом персональних даних (MedicalRecord)");
        String[] initialAllergies = {"Пеніцилін", "Пилок"};
        MedicalRecord record = new MedicalRecord("PAT-10025", "Олена Коваленко", 2, true, initialAllergies);
        System.out.println("Картка пацієнта: " + record);
        System.out.println("Чи є алергія на 'пеніцилін' (з маленької літери)? " + record.hasAllergyTo("пеніцилін"));
        System.out.println("Чи є алергія на 'Арахіс'? " + record.hasAllergyTo("Арахіс"));
        initialAllergies[0] = "ЗміненоЗовні";
        System.out.println("Після зміни зовнішнього масиву алергій : " + record);

        System.out.println("\n\nБлок 2\nЗавдання 9: Коло на площині через Композицію (Point2D + CompositeCircle)");
        CompositeCircle circle = new CompositeCircle(0.0, 0.0, 5.0);
        System.out.println("Створене коло: " + circle);
        Point2D insidePoint = new Point2D(3.0, 4.0);
        Point2D outsidePoint = new Point2D(6.0, 6.0);
        System.out.println("Чи містить коло точку " + insidePoint + "? " + circle.containsPoint(insidePoint));
        System.out.println("Чи містить коло точку " + outsidePoint + "? " + circle.containsPoint(outsidePoint));

        System.out.println("\n\nЗавдання 10: Автомобіль та Двигун: Делегування стану (Engine + Automobile)");
        Automobile myCar = new Automobile("BMW E30", "Benzin", 2000);
        System.out.println("Початковий стан: " + myCar);
        myCar.accelerate(20.0);
        myCar.startEngine();
        myCar.accelerate(30.0);
        System.out.println("Стан після розгону: " + myCar);
        myCar.stopEngine();
        System.out.println("Фінальний стан: " + myCar);

        System.out.println("\n\nЗавдання 11: Смартфон, Акумулятор та Дисплей (Battery + Display $\\to$ SmartDevice)");
        SmartDevice phone = new SmartDevice("Pixel Phone", 4000, 6.5, 80);
        System.out.println("Початковий стан: " + phone);
        phone.watchVideo(30);
        System.out.println("Стан після перегляду відео: " + phone);
        phone = new SmartDevice("Pixel Phone", 4000, 6.5, 50); // оновлюємо для прикладу
        phone.watchVideo(60);
        phone.chargeDevice(50);

        System.out.println("\n\nЗавдання 12: Відрізок та Вектор через дві Точки (Point2D $\\to$ LineSegment)");
        Point2D p1 = new Point2D(1.0, 2.0);
        Point2D p2 = new Point2D(4.0, 6.0);
        LineSegment segment = new LineSegment(p1, p2);
        System.out.println("Відрізок: " + segment);
        System.out.println("Довжина відрізка: " + segment.getLength());
        System.out.println("Середина відрізка: " + segment.getMidpoint());

        System.out.println("\n\nЗавдання 13: Банківська картка та Рахунок (BankAccount + PlasticCard)");
        BankAccount familyAccount = new BankAccount("UA283220010000026000", 5000.0);
        PlasticCard card1 = new PlasticCard("4141-****-****-1111", "05/29", familyAccount);
        PlasticCard card2 = new PlasticCard("5355-****-****-2222", "11/30", familyAccount);
        System.out.println("Початковий стан рахунку: " + familyAccount);
        card1.payAtTerminal(1200.0);
        card2.payAtTerminal(500.0);
        System.out.println("Стан рахунку після покупок обома картками: " + familyAccount);

        System.out.println("\n\nЗавдання 14: Герой RPG та Екіпірована Зброя (WeaponItem + HeroCharacter)");
        HeroCharacter warrior = new HeroCharacter("Артур", 15);
        WeaponItem sword = new WeaponItem("Екскалібур", 25, 30); // Міцність 30 (вистачить на 3 удари)
        warrior.equip(sword);
        System.out.println(warrior);
        System.out.println("Удар 1, завдано шкоди: " + warrior.attack());
        System.out.println("Удар 2, завдано шкоди: " + warrior.attack());
        System.out.println("Удар 3, завдано шкоди: " + warrior.attack());
        System.out.println("Удар 4 (зброя зламається): " + warrior.attack());
        System.out.println("Фінальний стан зброї: " + sword);

        System.out.println("\n\nЗавдання 15: Замовлення та Адреса доставки (DeliveryAddress + ParcelOrder)");
        DeliveryAddress address1 = new DeliveryAddress("Львів", "Городоцька", 5);
        ParcelOrder order = new ParcelOrder("ORD-9988", 2.5, address1);
        System.out.println("Початковий стан: " + order);
        DeliveryAddress newAddress = new DeliveryAddress("Одеса", "Дерибасівська", 12);
        order.changeDestination(newAddress);
        System.out.println("Після зміни адреси: " + order);
        order.markAsShipped();
        DeliveryAddress lateAddress = new DeliveryAddress("Харків", "Сумська", 3);
        order.changeDestination(lateAddress);

        System.out.println("\n\nЗавдання 16: Розумний термостат у кімнаті (TemperatureSensor + HeatingUnit $\\to$ ClimateController)");
        ClimateController climate = new ClimateController("Вітальня", 22.0, 23.0, 2.0);
        System.out.println("Початковий стан: " + climate);
        climate.regulate();
        climate.simulateOutsideDrop(20.0);
        climate.regulate();
        System.out.println("Фінальний стан: " + climate);

        System.out.println("\n\nБлок 3\nЗавдання 17: Ламана лінія та Багатокутник із масиву точок (Point2D[] $\\to$ Polyline)");
        Polyline polyline = new Polyline(5);
        polyline.addVertex(0.0, 0.0);
        polyline.addVertex(3.0, 0.0);
        polyline.addVertex(3.0, 4.0);
        System.out.println(polyline);
        System.out.println("Загальна довжина ламаної: " + polyline.getTotalLength());
        polyline.addVertex(0.0, 0.0);
        System.out.println("Периметр замкнутого контуру (трикутника): " + polyline.getClosedPerimeter());

        System.out.println("\n\nЗавдання 18: Кошик інтернет-магазину (OrderItem[] $\\to$ ShoppingOrder)");
        ShoppingOrder order1 = new ShoppingOrder(5);
        order1.addItem("Клавіатура", 1200.0, 1);
        order1.addItem("Мишка", 650.0, 2);
        order1.addItem("Килимок", 250.0, 1);
        order1.addItem("Мишка", 650.0, 1);
        System.out.println(order);

        System.out.println("\n\nЗавдання 19: Бібліотечна полиця (BookItem[] $\\to$ Bookshelf)");
        Bookshelf shelf = new Bookshelf("Фантастика", 3);
        shelf.putBook(new BookItem("Гаррі Поттер", "Джоан Ролінґ", 432));
        shelf.putBook(new BookItem("Володар Перснів", "Джон Р. Р. Толкін", 1178));
        shelf.putBook(new BookItem("Дюна", "Френк Герберт", 412));
        System.out.println(shelf);
        BookItem longest = shelf.findLongestBook();
        System.out.println("Найдовша книга на полиці: " + longest);

        System.out.println("\n\nЗавдання 20: Музичний плейлист з підрахунком тривалості (AudioTrack[] $\\to$ Playlist)");
        Playlist playlist = new Playlist("Улюблений рок", 4);
        playlist.addTrack(new AudioTrack("In the End", "Linkin Park", 216));
        playlist.addTrack(new AudioTrack("Numb", "Linkin Park", 185));
        playlist.addTrack(new AudioTrack("Enter Sandman", "Metallica", 331));
        System.out.println(playlist);

        System.out.println("\n\nЗавдання 21: Серверний кластер та Вузли (ServerNode[] $\\to$ DataCenterCluster)");
        DataCenterCluster cluster = new DataCenterCluster("Київ-ДЦ1", 3);
        cluster.addServer(new ServerNode("10.0.0.1", 16, true));
        cluster.addServer(new ServerNode("10.0.0.2", 32, false));
        cluster.addServer(new ServerNode("10.0.0.3", 8, true));
        System.out.println(cluster);
        cluster.deployContainer(10);
        cluster.deployContainer(20);
        cluster.deployContainer(4);
        System.out.println("Стан кластера після розгортання:");
        System.out.println(cluster);

        System.out.println("\n\nЗавдання 22: Навчальний курс та Модулі (CourseModule[] $\\to$ UniversityCourse)");
        UniversityCourse course = new UniversityCourse("Об'єктно-орієнтоване програмування", 3);
        course.addModule(new CourseModule("Основи ООП", 30, 30, 30.0));
        course.addModule(new CourseModule("Інкапсуляція та Композиція", 30, 30, 35.0));
        course.addModule(new CourseModule("Абстрактні класи", 20, 40, 35.0));
        System.out.println(course);

        System.out.println("\n\nЗавдання 23: Потяг та Вагони (TrainCarriage[] $\\to$ PassengerTrain)");
        PassengerTrain train = new PassengerTrain("Київ — Львів", 3);
        train.attachCarriage(new TrainCarriage(1, "Інтерсіті", 50));
        train.attachCarriage(new TrainCarriage(2, "Купе", 36));
        train.attachCarriage(new TrainCarriage(3, "Плацкарт", 54));
        System.out.println(train);
        train.bookTicketsInCarriage(2, 5);
        System.out.println("\nСтан потяга після бронювання:");
        System.out.println(train);

        System.out.println("\n\nЗавдання 24: Система рівнянь як Композиція лінійних рівнянь (LinearEquation[] $\\to$ EquationSystem)");
        EquationSystem system = new EquationSystem(2);
        system.addEquation(new LinearEquation(2.0, 1.0, 5.0));
        system.addEquation(new LinearEquation(1.0, -1.0, 1.0));
        System.out.println(system);
        double testX = 2.0;
        double testY = 1.0;
        boolean isSolution = system.checkSolution(testX, testY);
        System.out.printf("Чи є точка (%.1f, %.1f) розв'язком системи? %s\n",
                testX, testY, isSolution ? "Так" : "Ні");
        System.out.printf("Чи є точка (0.0, 0.0) розв'язком системи? %s\n",
                system.checkSolution(0.0, 0.0) ? "Так" : "Ні");

        System.out.println("\n\nБлок 4\nЗавдання 25: Абстрактна фігура (AbstractShape) $\\to$ CircleShape та RectangleShape");
        AbstractShape[] shapes = new AbstractShape[2];
        shapes[0] = new CircleShape("Червоний", 5.0);
        shapes[1] = new RectangleShape("Синій", 4.0, 6.0);
        for (AbstractShape shape : shapes) {
            System.out.println(shape);
        }

        System.out.println("\n\nЗавдання 26: Абстрактне джерело енергії (AbstractPowerPlant) $\\to$ Сонячна та Вітрова станції");
        AbstractPowerPlant[] plants = new AbstractPowerPlant[2];
        plants[0] = new SolarPowerPlant("Сонячна Долина", 50.0, 0.999999999999);
        plants[1] = new WindPowerPlant("Брівітер", 100.0, 14.0);
        double tariff = 1500.0;
        for (AbstractPowerPlant plant : plants) {
            System.out.println(plant);
            System.out.printf("  Очікуваний денний прибуток: %.2f грн\n", plant.calculateDailyProfit(tariff));
        }

        System.out.println("\n\nЗавдання 27: Абстрактний співробітник (AbstractEmployee) $\\to$ Погодинний та Ставковий");
        AbstractEmployee[] employees = new AbstractEmployee[2];
        employees[0] = new FixedSalaryEmployee("Олександр Петренко", "Менеджер проєкту", 35000.0);
        employees[1] = new HourlyEmployee("Марія Коваленко", "UI/UX Дизайнер", 250.0, 140);
        for (AbstractEmployee emp : employees) {
            System.out.println(emp);
        }

        System.out.println("\n\nЗавдання 28: Абстрактна математична послідовність (AbstractSequence) та сума перших $N$ членів");
        AbstractSequence[] sequences = new AbstractSequence[2];
        sequences[0] = new ArithmeticProgression(2.0, 3.0);   // Починається з 2, крок 3 (2, 5, 8, 11, 14...)
        sequences[1] = new GeometricProgression(3.0, 2.0);   // Починається з 3, знаменник 2 (3, 6, 12, 24, 48...)
        for (AbstractSequence seq : sequences) {
            System.out.println(seq);
            System.out.print("  Перші 5 елементів: ");
            for (int i = 1; i <= 5; i++) {
                System.out.printf("%.1f ", seq.getElement(i));
            }
            System.out.println();
        }

        System.out.println("\n\nЗавдання 29: Абстрактний банківський переказ (AbstractTransaction) з перевіркою комісії");
        AbstractTransaction[] transactions = new AbstractTransaction[2];
        transactions[0] = new CardTransferTransaction(1500.0, "4149 **** **** 1234");
        transactions[1] = new IbanPaymentTransaction(5000.0, "UA263800000000262012345678901", "Комуненерго");
        for (AbstractTransaction tx : transactions) {
            System.out.println("До виконання: " + tx);
            tx.execute();
            System.out.println("Після виконання: " + tx);
            System.out.println();
        }

        System.out.println("\n\nЗавдання 30: Абстрактне 3D-тіло (Solid3D) з обчисленням маси через густину");
        Solid3D[] solids = new Solid3D[2];
        solids[0] = new SphereSolid(3.0);
        solids[1] = new CylinderSolid(2.0, 5.0);
        double densitySteel = 7.85;
        for (Solid3D solid : solids) {
            System.out.println(solid);
            System.out.printf("  Маса тіла (при густині %.2f): %.2f кг\n",
                    densitySteel, solid.calculateMass(densitySteel));
        }

        System.out.println("\n\nЗавдання 31: Абстрактний датчик телеметрії (AbstractSensor) із тривогою");
        AbstractSensor[] sensors = new AbstractSensor[2];
        sensors[0] = new TemperatureSensor("TEMP-101", 85.5);
        sensors[1] = new PressureSensor("PRESS-202", 4.2);
        double tempThreshold = 80.0;
        double pressureThreshold = 5.0;
        for (int i = 0; i < sensors.length; i++) {
            System.out.println(sensors[i]);
            double threshold = (i == 0) ? tempThreshold : pressureThreshold;
            boolean critical = sensors[i].isCritical(threshold);
            System.out.printf("  Перевірка критичності (поріг %.1f): %s\n",
                    threshold, (critical ? " УВАГА: Критичний показник!" : " Норма"));
        }

        System.out.println("\n\nЗавдання 32: Абстрактний архіватор даних (AbstractCompressor)");
        AbstractCompressor[] compressors = new AbstractCompressor[2];
        compressors[0] = new RunLengthCompressor();
        compressors[1] = new DummyTextCompressor();
        String sampleText = "AAABBBCCCDD";
        for (AbstractCompressor comp : compressors) {
            System.out.println(comp);
            String compressed = comp.compress(sampleText);
            String decompressed = comp.decompress(compressed);
            System.out.printf("  Оригінал:   %s\n", sampleText);
            System.out.printf("  Стиснено:   %s\n", compressed);
            System.out.printf("  Розпаковано: %s\n\n", decompressed);
        }

        System.out.println("\n\nБлок 5\nЗавдання 33: Складальний цех ПК: DesktopPC компонує AbstractPcPart[]");
        AbstractDesktopPC[] computers = new AbstractDesktopPC[2];
        computers[0] = new GamingPC("AMD Ryzen 7 7700X", 32, 18000.0, "NVIDIA RTX 4070 Ti", true);
        computers[1] = new OfficePC("Intel Core i3-12100", 16, 9500.0, true);
        for (AbstractDesktopPC pc : computers) {
            System.out.println(pc);
        }

        System.out.println("\n\nЗавдання 34: Космічний корабель та Абстрактні двигуни (Spacecraft + AbstractThruster[])");
        AbstractEngine[] engines = new AbstractEngine[2];
        engines[0] = new IonEngine(45.0, 5000.0);
        engines[1] = new PlasmaEngine(320.0, 200.0);
        double testShipMass = 15000.0;
        for (AbstractEngine engine : engines) {
            System.out.println(engine);
            System.out.printf("  Прискорення для корабля масою %.0f кг: %.4f м/с²\n",
                    testShipMass, engine.calculateAcceleration(testShipMass));
            System.out.printf("  Витрата палива: %.2f т/год\n",
                    engine.calculateFuelConsumptionRate());
        }

        System.out.println("\n\nЗавдання 35: Креслення ділянки: LandPlot компонує масив AbstractShape[]");
        LandPlot myPlot = new LandPlot(1000.0, 5);
        System.out.println("Початковий стан ділянки: " + myPlot);
        AbstractShape house = new RectangleShape("Цегляний", 15.0, 20.0); // Площа 300 м²
        AbstractShape pool = new CircleShape("Блакитний", 8.0);             // Площа ~201.06 м²
        AbstractShape bigGarage = new RectangleShape("Сірий", 15.0, 15.0);  // Площа 225 м² (перевищить ліміт 60%)
        myPlot.addStructure(house);
        myPlot.addStructure(pool);
        myPlot.addStructure(bigGarage); // Цей об'єкт має бути відхилений системою
        System.out.println("Фінальний стан ділянки після спроби будівництва:");
        System.out.println(myPlot);

        System.out.println("\n\nЗавдання 36: Портфель інвестора: InvestmentPortfolio + AbstractAsset[]");
        InvestmentPortfolio portfolio = new InvestmentPortfolio("Олександр", 5);
        portfolio.addAsset(new GovernmentBond("UA-GOV-2027", 50000.0, 15.5)); // ОВДП під 15.5%
        portfolio.addAsset(new DividendStock("AAPL", 80000.0, 10.0, 3.0, 0.095)); // Акції Apple
        System.out.println(portfolio);
        System.out.println("Деталізація активів у портфелі:");
        for (AbstractAsset asset : portfolio.getAssets()) {
            System.out.println("  - " + asset);}

        System.out.println("\n\nЗавдання 37: Бойовий Загін RPG: RaidParty компонує AbstractHeroUnit[]");
        RaidParty party = new RaidParty("Shadow Dragons", 4);
        party.addHero(new TankWarrior("Тролль Воїн", 1200, 150));
        party.addHero(new ArcaneMage("Архімаг Ельріон", 600, 220));
        System.out.println(party);
        int dungeonDifficulty = 2500;
        party.isReadyForRaid(dungeonDifficulty);
        System.out.println("Детальний склад загону:");
        for (AbstractHeroUnit hero : party.getMembers()) {
            System.out.println("  - " + hero);}

        System.out.println("\n\nЗавдання 38: Автономна лабораторія: SmartLab + AbstractSensor[] + EmergencySiren");
        SmartLab lab = new SmartLab("Біо-Лабораторія №3", 3);
        lab.addSensor(new PressureSensor("Датчик-Рек-01", 35.0)); // Норма (нижче порогу 50.0)
        lab.addSensor(new PressureSensor("Датчик-Шлюз-02", 68.0)); // Критичне значення (вище 50.0)
        System.out.println(lab);
        System.out.println();
        lab.runDiagnostics();

        System.out.println("\n\nЗавдання 39: Математичний конвеєр обробки сигналів: SignalProcessor + AbstractFilter[]");
        SignalProcessor processor = new SignalProcessor(3);
        processor.addFilter(new AmplifierFilter(2.0));
        processor.addFilter(new ClippingFilter(5.0));
        double[] rawSignal = {1.5, -3.0, 4.0, -6.0, 2.0};
        System.out.println("Сигнал до обробки:    " + Arrays.toString(rawSignal));
        double[] processedSignal = processor.processSignal(rawSignal);
        System.out.println("Сигнал після конвеєра: " + Arrays.toString(processedSignal));
    }
}
