package semester1.practice09;

public class Point2D {
    private double x;
    private double y;
    public Point2D(double x, double y) {
        this.x = x;
        this.y = y;}
    public double distanceTo(Point2D other) {
        if (other == null) {
            return 0.0;}
        double dx = this.x - other.x;
        double dy = this.y - other.y;
        return Math.sqrt(dx * dx + dy * dy);}
    public double getX() {
        return x;}
    public double getY() {
        return y;}
    @Override
    public String toString() {
        return String.format("(%.2f, %.2f)", x, y);}
}
