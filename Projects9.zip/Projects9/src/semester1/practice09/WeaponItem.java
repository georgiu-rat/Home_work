package semester1.practice09;

public class WeaponItem {
    private final String name;
    private final int bonusDamage;
    private int durability;
    public WeaponItem(String name, int bonusDamage, int durability) {
        this.name = (name == null || name.isBlank()) ? "Іржавий ніж" : name;
        this.bonusDamage = Math.max(0, bonusDamage);
        this.durability = Math.max(0, Math.min(100, durability));}
    public int useWeapon() {
        if (durability <= 0) {
            return 0;}
        durability = Math.max(0, durability - 10);
        return bonusDamage;}
    public boolean isBroken() {
        return durability <= 0;}
    public String getName() {
        return name;}
    @Override
    public String toString() {
        return String.format("WeaponItem{назва='%s', бонус урону=+%d, міцність=%d%%}",
                name, bonusDamage, durability);}
}

