package semester1.practice09;

public class HighSecuritySafe {
    private final int pinCode;
    private double storedCash;
    private int failedAttempts;
    private boolean permanentlyBlocked;

    public HighSecuritySafe(int pinCode, double initialCash) {
        this.pinCode = pinCode;
        this.storedCash = Math.max(0.0, initialCash);
        this.failedAttempts = 0;
        this.permanentlyBlocked = false;}
    private boolean checkAccess(int enteredPin) {
        if (permanentlyBlocked) {
            System.out.println("️ УВАГА: Сейф НАЗАВЖДИ заблоковано через перевищення кількості спроб!");
            return false;}
        if (enteredPin == this.pinCode) {
            this.failedAttempts = 0;
            return true;
        } else {
            this.failedAttempts++;
            System.out.printf(" Невірний пін-код! Залишилось спроб: %d\n", (3 - this.failedAttempts));
            if (this.failedAttempts >= 3) {
                this.permanentlyBlocked = true;
                System.out.println(" СЕЙФ ЗАБЛОКОВАНО НАЗАВЖДИ! Зверніться до служби безпеки.");}
            return false;}}
    public boolean putCash(int pin, double amount) {
        if (!checkAccess(pin)) {
            return false;}
        if (amount <= 0) {
            System.out.println("Помилка: Сума для поповнення має бути більшою за нуль.");
            return false;}
        this.storedCash += amount;
        System.out.printf(" Успішно внесено %.2f грн до сейфа.\n", amount);
        return true;}
    public boolean takeCash(int pin, double amount) {
        if (!checkAccess(pin)) {
            return false;}
        if (amount <= 0) {
            System.out.println("Помилка: Сума для зняття має бути більшою за нуль.");
            return false;}
        if (this.storedCash < amount) {
            System.out.println("Помилка: У сейфі недостатньо готівки.");
            return false;}

        this.storedCash -= amount;
        System.out.printf(" Успішно знято %.2f грн з сейфа.\n", amount);
        return true;}
    public double getStoredCash() {
        return storedCash;}
    public boolean isPermanentlyBlocked() {
        return permanentlyBlocked;}
    @Override
    public String toString() {
        return String.format("HighSecuritySafe{cash=%.2f, blocked=%s, failedAttempts=%d}",
                storedCash, permanentlyBlocked, failedAttempts);}
}
