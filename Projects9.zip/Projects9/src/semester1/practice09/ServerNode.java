package semester1.practice09;

public class ServerNode {
    private final String ipAddress;
    private final int totalRamGb;
    private int usedRamGb;
    private boolean online;
    public ServerNode(String ipAddress, int totalRamGb, boolean online) {
        this.ipAddress = (ipAddress == null || ipAddress.isBlank()) ? "192.168.1.1" : ipAddress;
        this.totalRamGb = Math.max(4, totalRamGb);
        this.usedRamGb = 0;
        this.online = online;}
    public int getFreeRamGb() {
        return online ? (totalRamGb - usedRamGb) : 0;}
    public boolean deploy(int requiredRamGb) {
        if (!online || requiredRamGb <= 0) {
            return false;}
        if (getFreeRamGb() >= requiredRamGb) {
            usedRamGb += requiredRamGb;
            return true;}
        return false;}
    public boolean isOnline() {
        return online;}
    public String getIpAddress() {
        return ipAddress;}
    @Override
    public String toString() {
        return String.format("Сервер [%s] | RAM: %d/%d ГБ | Статус: %s",
                ipAddress, usedRamGb, totalRamGb, (online ? "  Онлайн" : "  Офлайн"));}
}
