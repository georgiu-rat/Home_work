package semester1.practice09.task36;

public class GovernmentBond extends AbstractAsset {
    private final double couponRatePercent;
    public GovernmentBond(String ticker, double investedAmount, double couponRatePercent) {
        super(ticker, investedAmount);
        this.couponRatePercent = Math.max(0.0, couponRatePercent);}
    @Override
    public double calculateAnnualReturn() {
        return investedAmount * (couponRatePercent / 100.0);}
    @Override
    public String toString() {
        return String.format("GovernmentBond{ставка=%.1f%%, %s}", couponRatePercent, super.toString());}
}
