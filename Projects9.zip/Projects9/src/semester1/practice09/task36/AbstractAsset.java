package semester1.practice09.task36;

public abstract class AbstractAsset {
    protected final String ticker;
    protected double investedAmount;
    public AbstractAsset(String ticker, double investedAmount) {
        this.ticker = (ticker == null || ticker.isBlank()) ? "UNKNOWN" : ticker;
        this.investedAmount = Math.max(0.0, investedAmount);}
    public String getTicker() {
        ticker.toString();
        return ticker;}
    public double getInvestedAmount() {
        return investedAmount;}
    public abstract double calculateAnnualReturn();
    @Override
    public String toString() {
        return String.format("Актив [%s] — Інвестовано: %.2f грн, Очікуваний дохід: %.2f грн",
                ticker, investedAmount, calculateAnnualReturn());}
}
