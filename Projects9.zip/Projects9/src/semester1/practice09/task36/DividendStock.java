package semester1.practice09.task36;

public class DividendStock extends AbstractAsset {
    private final double expectedGrowthPercent; // очікуваний ріст ціни
    private final double dividendYieldPercent;  // дивіденднахідність
    private final double taxRate;               // податок на дивіденди (наприклад, 0.095 для 9.5%)
    public DividendStock(String ticker, double investedAmount, double expectedGrowthPercent, double dividendYieldPercent, double taxRate) {
        super(ticker, investedAmount);
        this.expectedGrowthPercent = expectedGrowthPercent;
        this.dividendYieldPercent = Math.max(0.0, dividendYieldPercent);
        this.taxRate = Math.clamp(taxRate, 0.0, 1.0);}
    @Override
    public double calculateAnnualReturn() {
        double growthReturn = investedAmount * (expectedGrowthPercent / 100.0);
        double grossDividend = investedAmount * (dividendYieldPercent / 100.0);
        double netDividend = grossDividend * (1.0 - taxRate);
        return growthReturn + netDividend;}
    @Override
    public String toString() {
        return String.format("DividendStock{ріст=%.1f%%, дивіденди=%.1f%%, %s}",
                expectedGrowthPercent, dividendYieldPercent, super.toString());}
}