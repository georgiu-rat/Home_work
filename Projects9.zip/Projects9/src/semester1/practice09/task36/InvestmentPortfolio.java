package semester1.practice09.task36;

import java.util.Arrays;

public class InvestmentPortfolio {
    private final String investorName;
    private final AbstractAsset[] assets;
    private int assetCount;
    public InvestmentPortfolio(String investorName, int maxCapacity) {
        this.investorName = (investorName == null || investorName.isBlank()) ? "Інвестор" : investorName;
        int capacity = Math.max(1, maxCapacity);
        this.assets = new AbstractAsset[capacity];
        this.assetCount = 0;}
    public boolean addAsset(AbstractAsset asset) {
        if (asset == null) return false;
        if (assetCount >= assets.length) {
            System.out.println("⚠️ Портфель заповнено, новий актив неможливо додати.");
            return false;}
        assets[assetCount++] = asset;
        return true;}
    public double getTotalInvestedAmount() {
        double total = 0.0;
        for (int i = 0; i < assetCount; i++) {
            total += assets[i].getInvestedAmount();}
        return total;}
    public double getTotalAnnualReturn() {
        double totalReturn = 0.0;
        for (int i = 0; i < assetCount; i++) {
            totalReturn += assets[i].calculateAnnualReturn();}
        return totalReturn;}
    public AbstractAsset[] getAssets() {
        return Arrays.copyOf(assets, assetCount);}
    @Override
    public String toString() {
        return String.format("InvestmentPortfolio{інвестор='%s', активів=%d, всього інвестовано=%.2f грн, очікуваний річний дохід=%.2f грн}",
                investorName, assetCount, getTotalInvestedAmount(), getTotalAnnualReturn());}
}
