package semester1.practice09.task16;

public class TemperatureSensor {
    private double currentTemp;
    public TemperatureSensor(double currentTemp) {
        this.currentTemp = currentTemp;}
    public void setCurrentTemp(double currentTemp) {
        this.currentTemp = currentTemp;}
    public double getCurrentTemp() {
        return currentTemp;}
    @Override
    public String toString() {
        return String.format("TemperatureSensor{поточна температура=%.1f°C}", currentTemp);}
}
