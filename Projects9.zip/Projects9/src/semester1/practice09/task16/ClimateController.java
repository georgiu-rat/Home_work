package semester1.practice09.task16;

public class ClimateController {
    private final String roomName;
    private double targetTemp;
    private final TemperatureSensor sensor;
    private final HeatingUnit heatingUnit;
    public ClimateController(String roomName, double targetTemp, double initialTemp, double heaterPowerKw) {
        this.roomName = (roomName == null || roomName.isBlank()) ? "Кімната" : roomName;
        this.targetTemp = targetTemp;
        this.sensor = new TemperatureSensor(initialTemp);
        this.heatingUnit = new HeatingUnit(heaterPowerKw);}
    public void regulate() {
        double currentTemp = sensor.getCurrentTemp();
        System.out.printf("️ [%s] Перевірка клімату: поточна=%.1f°C, бажана=%.1f°C\n",
                roomName, currentTemp, targetTemp);
        if (currentTemp < targetTemp - 0.5) {
            heatingUnit.turnOn();
            System.out.println(" Обігрівач УВІМКНЕНО.");}
        else if (currentTemp >= targetTemp) {
            heatingUnit.turnOff();
            System.out.println("️ Обігрівач ВИМКНЕНО (тепло).");}
    }
    public void simulateOutsideDrop(double newTemp) {
        sensor.setCurrentTemp(newTemp);
        System.out.printf(" Температура в кімнаті змінилася до %.1f°C\n", newTemp);}
    @Override
    public String toString() {
        return String.format("ClimateController{кімната='%s', цільова=%.1f°C, [%s], [%s]}",
                roomName, targetTemp, sensor, heatingUnit);}
}
