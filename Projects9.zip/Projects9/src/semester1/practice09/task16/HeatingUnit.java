package semester1.practice09.task16;

public class HeatingUnit {
    private boolean heatingOn;
    private final double powerKw;
    public HeatingUnit(double powerKw) {
        this.powerKw = Math.max(0.5, powerKw);
        this.heatingOn = false;}
    public void turnOn() {
        this.heatingOn = true;}
    public void turnOff() {
        this.heatingOn = false;}
    public boolean isHeatingOn() {
        return heatingOn;}
    @Override
    public String toString() {
        return String.format("HeatingUnit{включено=%s, потужність=%.1f кВт}", heatingOn, powerKw);}
}
