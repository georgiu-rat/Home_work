package semester1.practice09;

public class ImmutableGeoPoint {
    private final double latitude;
    private final double longitude;
    public ImmutableGeoPoint(double latitude, double longitude) {
        this.latitude = Math.max(-90.0, Math.min(90.0, latitude));
        this.longitude = Math.max(-180.0, Math.min(180.0, longitude));}
    public double getLatitude() {
        return latitude;}

    public double getLongitude() {
        return longitude;}
    public ImmutableGeoPoint shift(double dLat, double dLon) {
        return new ImmutableGeoPoint(this.latitude + dLat, this.longitude + dLon);}
    @Override
    public String toString() {
        return String.format("ImmutableGeoPoint{lat=%.4f, lon=%.4f}", latitude, longitude);}
}

