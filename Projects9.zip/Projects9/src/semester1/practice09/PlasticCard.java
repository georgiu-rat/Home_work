package semester1.practice09;

public class PlasticCard {
    private final String cardNumber;
    private final String expiryDate;
    private boolean blocked;
    private final BankAccount linkedAccount;
    public PlasticCard(String cardNumber, String expiryDate, BankAccount linkedAccount) {
        this.cardNumber = (cardNumber == null || cardNumber.isBlank()) ? "0000-0000-0000-0000" : cardNumber;
        this.expiryDate = (expiryDate == null || expiryDate.isBlank()) ? "12/28" : expiryDate;
        this.blocked = false;
        this.linkedAccount = linkedAccount;}
    public boolean payAtTerminal(double amount) {
        if (blocked) {
            System.out.println("  Помилка: Картку заблоковано!");
            return false;}
        if (linkedAccount == null) {
            System.out.println("  Помилка: До картки не прив'язано жодного рахунку!");
            return false;}
        boolean success = linkedAccount.withdraw(amount);
        if (success) {
            System.out.printf("  Успішна оплата карткою %s на суму %.2f грн.\n", cardNumber, amount);
        } else {
            System.out.printf("  Відмова у платежі карткою %s: недостатньо коштів на рахунку.\n", cardNumber);}
        return success;}
    public void blockCard() {
        this.blocked = true;}
    public void unblockCard() {
        this.blocked = false;}
    public BankAccount getLinkedAccount() {
        return linkedAccount;}
    @Override
    public String toString() {
        return String.format("PlasticCard{номер='%s', активна=%s, рахунок=[%s]}",
                cardNumber, !blocked, linkedAccount);}
}
