package semester1.practice09;

public class HeroCharacter {
    private final String nickname;
    private int baseStrength;
    private WeaponItem equippedWeapon;
    public HeroCharacter(String nickname, int baseStrength) {
        this.nickname = (nickname == null || nickname.isBlank()) ? "Безіменний Герой" : nickname;
        this.baseStrength = Math.max(1, baseStrength);
        this.equippedWeapon = null;}
    public void equip(WeaponItem newWeapon) {
        this.equippedWeapon = newWeapon;
        if (newWeapon != null) {
            System.out.printf(" ️ %s озброюється: %s\n", nickname, newWeapon.getName());
        } else {
            System.out.printf("️  %s зняв усю зброю.\n", nickname);}
    }
    public int attack() {
        int totalDamage = baseStrength;
        if (equippedWeapon != null) {
            if (equippedWeapon.isBroken()) {
                System.out.printf("️ %s намагається вдарити, але зброя '%s' зламана!\n",
                        nickname, equippedWeapon.getName());
            } else {
                totalDamage += equippedWeapon.useWeapon();}
        }
        return totalDamage;}
    @Override
    public String toString() {
        String weaponStr = (equippedWeapon != null) ? equippedWeapon.toString() : "Без зброї";
        return String.format("HeroCharacter{ім'я='%s', базова сила=%d, екіпірування=[%s]}",
                nickname, baseStrength, weaponStr);}
}
