package semester1.practice09;

import java.util.Arrays;

public class MedicalRecord {
    private final String patientId;
    private String fullName;
    private int bloodGroup; // 1 (I), 2 (II), 3 (III), 4 (IV)
    private boolean rhPositive;
    private final String[] allergies;
    public MedicalRecord(String patientId, String fullName, int bloodGroup, boolean rhPositive, String[] allergies) {
        this.patientId = (patientId == null || patientId.isBlank()) ? "UNKNOWN-ID" : patientId;
        this.fullName = (fullName == null || fullName.isBlank()) ? "Невідомий пацієнт" : fullName;
        this.bloodGroup = Math.max(1, Math.min(4, bloodGroup));
        this.rhPositive = rhPositive;
        if (allergies == null) {
            this.allergies = new String[0];
        } else {
            this.allergies = Arrays.copyOf(allergies, allergies.length);}}
    public boolean hasAllergyTo(String substance) {
        if (substance == null) {
            return false;}
        for (String allergy : allergies) {
            if (allergy != null && allergy.equalsIgnoreCase(substance)) {
                return true;}
        }
        return false;}
    public String getPatientId() {
        return patientId;}
    public String getFullName() {
        return fullName;}
    public void setFullName(String fullName) {
        if (fullName != null && !fullName.isBlank()) {
            this.fullName = fullName;}
    }
    public int getBloodGroup() {
        return bloodGroup;}

    public boolean isRhPositive() {
        return rhPositive;}
    public String[] getAllergies() {
        return Arrays.copyOf(allergies, allergies.length);}
    private String getBloodGroupRoman() {
        switch (bloodGroup) {
            case 1: return "I (O)";
            case 2: return "II (A)";
            case 3: return "III (B)";
            case 4: return "IV (AB)";
            default: return "Unknown";}
    }
    @Override
    public String toString() {
        String rhStr = rhPositive ? "Rh+" : "Rh-";
        return String.format("MedicalRecord{ID='%s', пацієнт='%s', група крові='%s %s', алергії=%s}",
                patientId, fullName, getBloodGroupRoman(), rhStr, Arrays.toString(allergies));}
}
