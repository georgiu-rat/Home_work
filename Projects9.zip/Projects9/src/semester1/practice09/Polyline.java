package semester1.practice09;

import java.util.Arrays;

public class Polyline {
    private final Point2D[] vertices;
    private int count;
    public Polyline(int capacity) {
        int cap = Math.max(2, capacity);
        this.vertices = new Point2D[cap];
        this.count = 0;}
    public void addVertex(double x, double y) {
        if (count < vertices.length) {
            vertices[count++] = new Point2D(x, y);
        } else {
            System.out.println("⚠️ Попередження: Масив вершин ламаної заповнено!");}
    }
    public void addVertex(Point2D point) {
        if (point != null && count < vertices.length) {
            vertices[count++] = new Point2D(point.getX(), point.getY());}
    }
    public double getTotalLength() {
        double totalLength = 0.0;
        for (int i = 0; i < count - 1; i++) {
            totalLength += vertices[i].distanceTo(vertices[i + 1]);}
        return totalLength;}
    public double getClosedPerimeter() {
        if (count < 3) {
            return getTotalLength();}
        double perimeter = getTotalLength();
        perimeter += vertices[count - 1].distanceTo(vertices[0]); // Замикаємо контур
        return perimeter;}
    public int getVertexCount() {
        return count;}
    public Point2D[] getVertices() {
        return Arrays.copyOf(vertices, count);}
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Polyline{вершини=[");
        for (int i = 0; i < count; i++) {
            sb.append(vertices[i]);
            if (i < count - 1) sb.append(", ");}
        sb.append(String.format("], довжина=%.2f}", getTotalLength()));
        return sb.toString();}
}
