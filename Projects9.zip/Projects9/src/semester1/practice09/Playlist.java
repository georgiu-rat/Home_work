package semester1.practice09;

public class Playlist {
    private String name;
    private final AudioTrack[] tracks;
    private int trackCount;
    public Playlist(String name, int capacity) {
        this.name = (name == null || name.isBlank()) ? "Мій плейлист" : name;
        int cap = Math.max(1, capacity);
        this.tracks = new AudioTrack[cap];
        this.trackCount = 0;}
    public boolean addTrack(AudioTrack track) {
        if (track == null) {
            System.out.println("Помилка: Неможливо додати порожній трек (null).");
            return false;}
        if (trackCount < tracks.length) {
            tracks[trackCount++] = track;
            return true;
        } else {
            System.out.println("Попередження: Плейлист '" + name + "' переповнений!");
            return false;}}
    public int getTotalDurationSeconds() {
        int totalSeconds = 0;
        for (int i = 0; i < trackCount; i++) {
            totalSeconds += tracks[i].getDurationSeconds();}
        return totalSeconds;}
    public String getFormattedTotalDuration() {
        int totalSec = getTotalDurationSeconds();
        int minutes = totalSec / 60;
        int seconds = totalSec % 60;
        return String.format("%d хв %d сек", minutes, seconds);}
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(String.format("Playlist{назва='%s', треків=%d/%d}:\n", name, trackCount, tracks.length));
        for (int i = 0; i < trackCount; i++) {
            sb.append(String.format("  %d. %s\n", i + 1, tracks[i]));}
        sb.append(String.format("  Загальна тривалість: %s", getFormattedTotalDuration()));
        return sb.toString();}
}
