package semester1.practice09;

public class RgbColor {
    private final int red;
    private final int green;
    private final int blue;

    public RgbColor(int red, int green, int blue) {
        this.red = clamp(red);
        this.green = clamp(green);
        this.blue = clamp(blue);}
    private static int clamp(int val) {
        return Math.max(0, Math.min(255, val));}
    public String toHex() {
        return String.format("#%02X%02X%02X", red, green, blue);}
    public RgbColor invert() {
        return new RgbColor(255 - this.red, 255 - this.green, 255 - this.blue);}
    public RgbColor mixWith(RgbColor other) {
        if (other == null) {
            return this;}
        int mixedRed = (this.red + other.red) / 2;
        int mixedGreen = (this.green + other.green) / 2;
        int mixedBlue = (this.blue + other.blue) / 2;
        return new RgbColor(mixedRed, mixedGreen, mixedBlue);}
    public int getRed() {
        return red;}
    public int getGreen() {
        return green;}
    public int getBlue() {
        return blue;}
    @Override
    public String toString() {
        return String.format("RgbColor{RGB(%d, %d, %d), HEX='%s'}", red, green, blue, toHex());}


}
