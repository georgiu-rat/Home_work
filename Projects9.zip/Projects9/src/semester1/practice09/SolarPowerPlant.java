package semester1.practice09;

public class SolarPowerPlant extends AbstractPowerPlant {
    private final double sunIntensityFactor;
    public SolarPowerPlant(String stationName, double baseCapacityMw, double sunIntensityFactor) {
        super(stationName, baseCapacityMw);
        this.sunIntensityFactor = Math.max(0.0, Math.min(1.0, sunIntensityFactor));}
    @Override
    public double generateMegawatts() {
        return baseCapacityMw * sunIntensityFactor;}
    @Override
    public String toString() {
        return String.format("SolarPowerPlant{сонце=%.0f%%, %s}",
                sunIntensityFactor * 100, super.toString());}
}