package semester1.practice09;

public class TrainCarriage {
    private final int carriageNumber;
    private final String type;
    private final int totalSeats;
    private int occupiedSeats;
    public TrainCarriage(int carriageNumber, String type, int totalSeats) {
        this.carriageNumber = Math.max(1, carriageNumber);
        this.type = (type == null || type.isBlank()) ? "Плацкарт" : type;
        this.totalSeats = Math.max(10, totalSeats);
        this.occupiedSeats = 0;}
    public int getCarriageNumber() {
        return carriageNumber;}
    public int getFreeSeats() {
        return totalSeats - occupiedSeats;}
    public boolean bookSeats(int seatsCount) {
        if (seatsCount <= 0) return false;
        if (getFreeSeats() >= seatsCount) {
            occupiedSeats += seatsCount;
            return true;}
        return false;}
    @Override
    public String toString() {
        return String.format("Вагон №%d (%s) — Вільно місць: %d/%d",
                carriageNumber, type, getFreeSeats(), totalSeats);}
}
