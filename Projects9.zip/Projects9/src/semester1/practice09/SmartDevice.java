package semester1.practice09;

public class SmartDevice {
    private final String brand;
    private final Battery battery;   // КОМПОЗИЦІЯ: Пристрій МАЄ акумулятор
    private final Display display; // КОМПОЗИЦІЯ: Пристрій МАЄ дисплей

    public SmartDevice(String brand, int batteryCapacityMah, double displayDiagonal, int brightness) {
        this.brand = (brand == null || brand.isBlank()) ? "SmartGadget" : brand;
        this.battery = new Battery(batteryCapacityMah);
        this.display = new Display(displayDiagonal, brightness);}
    public void watchVideo(int minutes) {
        if (battery.isEmpty()) {
            System.out.println(brand + ":  Пристрій розряджений! Увімкніть зарядку.");
            return;}
        if (minutes <= 0) {
            return;}
        System.out.printf("  Перегляд відео на %s протягом %d хв...\n", brand, minutes);
        int drainRatePer10Min = (display.getBrightnessPercent() > 70) ? 2 : 1;
        int totalDrain = (minutes / 10) * drainRatePer10Min;
        if (totalDrain == 0 && minutes > 0) {
            totalDrain = 1;}
        battery.drain(totalDrain);
        if (battery.isEmpty()) {
            System.out.println(brand + ":   Батарея сіла до 0%. Пристрій вимкнувся!");}
    }
    public void chargeDevice(int percent) {
        battery.charge(percent);
        System.out.printf("  %s заряджено. Поточний заряд: %d%%\n", brand, battery.getChargePercent());}

    @Override
    public String toString() {
        return String.format("SmartDevice{бренд='%s', %s, %s}", brand, battery, display);}
}
