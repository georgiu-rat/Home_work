package semester1.practice09;

public class PassengerTrain {
    private final String route;
    private final TrainCarriage[] carriages;
    private int carriageCount;
    public PassengerTrain(String route, int capacity) {
        this.route = (route == null || route.isBlank()) ? "Маршрут" : route;
        int cap = Math.max(1, capacity);
        this.carriages = new TrainCarriage[cap];
        this.carriageCount = 0;}
    public boolean attachCarriage(TrainCarriage carriage) {
        if (carriage == null) return false;
        if (carriageCount < carriages.length) {
            carriages[carriageCount++] = carriage;
            return true;}
        System.out.println("Попередження: До потяга '" + route + "' неможливо додати більше вагонів!");
        return false;}
    public int getTotalFreeSeats() {
        int totalFree = 0;
        for (int i = 0; i < carriageCount; i++) {
            totalFree += carriages[i].getFreeSeats();}
        return totalFree;}
    public boolean bookTicketsInCarriage(int carriageNumber, int seatsToBook) {
        for (int i = 0; i < carriageCount; i++) {
            if (carriages[i].getCarriageNumber() == carriageNumber) {
                boolean success = carriages[i].bookSeats(seatsToBook);
                if (success) {
                    System.out.printf("Успішно заброньовано %d місць у вагоні №%d\n", seatsToBook, carriageNumber);
                } else {
                    System.out.printf("Не вдалося заброньовати %d місць у вагоні №%d (бракує вільних місць)\n", seatsToBook, carriageNumber);}
                return success;}
        }
        System.out.println("Помилка: Вагон з номером " + carriageNumber + " не знайдено у потязі.");
        return false;}
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(String.format("PassengerTrain{маршрут='%s', вагонів=%d, вільних місць загалом=%d}:\n",
                route, carriageCount, getTotalFreeSeats()));
        for (int i = 0; i < carriageCount; i++) {
            sb.append("  - ").append(carriages[i]).append("\n");}
        return sb.toString();}
}
