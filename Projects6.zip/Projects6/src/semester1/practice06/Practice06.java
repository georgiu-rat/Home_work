package semester1.practice06;

import java.util.concurrent.CyclicBarrier;

public class Practice06 {
    public static void main(String[] args) {
        Student s = new Student();
        s.name = "Денис";
        s.age = 19;
        s.gpa = 4.75;
        System.out.println(s.name + ", " + s.age + ", " + s.gpa);

        System.out.println("\n\nЗавдання 2: Два незалежні автомобілі");
        Car car1 = new Car();
        Car car2 = new Car();

        car1.brand = "Toyota";
        car1.model = "Camry";
        car1.year = 2021;
        car1.speed = 180;

        car2.brand = "BMW";
        car2.model = "M5";
        car2.year = 2023;
        car2.speed = 250;

        System.out.println("Авто 1: " + car1.brand + " " + car1.model + " (" + car1.year + " р., " + car1.speed + " км/год)");
        System.out.println("Авто 2: " + car2.brand + " " + car2.model + " (" + car2.year + " р., " + car2.speed + " км/год)");
        if (car1.year > car2.year) {
            System.out.println("новіший: " + car1.brand + " " + car1.model);
        } else if (car2.year > car1.year) {
            System.out.println("новіший : " + car2.brand + " " + car2.model);
        } else {
            System.out.println("обоє автомобілі одного року випуску.");
        }
        System.out.println("\n\nЗавдання 3: Дослідження значень за замовчуванням (Default Values)");
        Book emptyBook = new Book();
        System.out.println(emptyBook.title + " змінна 1|" + emptyBook.author + " змінна 2|" + emptyBook.isRead + " зміна 3|" + emptyBook.isRead + " зміна 4|");

        System.out.println("\n\nЗавдання 4: Геометричний прямокутник");
        Rectangle r1 = new Rectangle();
        r1.height = 7.5;
        r1.width = 4.0;
        System.out.println("плоша: " + r1.width * r1.height + " периметр " + 2 * (r1.width + r1.height));

        System.out.println("\n\nЗавдання 5: Партія товару на складі");
        Product a1 = new Product();
        a1.name = "Монітор";
        a1.price = 6500.0;
        a1.quantity = 8;
        System.out.println("товар: " + a1.name + " в кількості " + a1.quantity + " штук коштує: " + a1.price * a1.quantity);

        System.out.println("\n\nЗавдання 6: Смартфон та зміна стану");
        Smartphone s1 = new Smartphone();
        s1.model = "iPhone 15";
        s1.batteryLevel = 100;
        s1.isTurnedOn = true;
        s1.batteryLevel -= 35;
        if (s1.batteryLevel <= 0) {
            s1.batteryLevel = 0;
            s1.isTurnedOn = false;
        }
        System.out.println("Модель: " + s1.model);
        System.out.println("Поточний заряд: " + s1.batteryLevel + "%");
        System.out.println("Телефон увімкнено: " + s1.isTurnedOn);

        System.out.println("\n\nЗавдання 7: Точка на площині та відстань");
        Point2D A = new Point2D();
        Point2D B = new Point2D();
        A.x = 0;
        A.y = 0;
        B.x = 3;
        B.y = 4;
        System.out.println("Відстань між точками A і B: " + Math.sqrt(Math.pow(B.x - A.x, 2) + Math.pow(B.y - A.y, 2)));

        System.out.println("\n\nЗавдання 8: Дослідження посилань у пам'яті (Reference Sharing)");
        Student first = new Student();
        first.name = "Іван";
        System.out.println(first.name);

        Student second = first;
        second.name = "Петро";
        System.out.println(first.name);

        System.out.println("\n\nЗавдання 9: Клас Greeter (Привітання)");
        Greeter g = new Greeter();
        g.sayHello();
        g.sayHelloTo("Олена");

        System.out.println("\n\nЗавдання 10: Тварина з виведенням інформації");
        Animal cat = new Animal();
        Animal dog = new Animal();
        cat.species = "кіт";
        cat.name = "мошонка";
        dog.species = "собака";
        dog.name = "борис";
        cat.makeSound();
        cat.printInfo();
        dog.makeSound();
        dog.printInfo();

        System.out.println("\n\nЗавдання 11: Лічильник подій (Counter)");
        Counter n = new Counter();
        n.increment();
        n.increment();
        n.increment();
        n.decrement();
        n.printCount();

        System.out.println("\n\nЗавдання 12: Світлофор (TrafficLight)");
        TrafficLight l = new TrafficLight();
        l.changeColor("Червоний");
        l.showSignal();
        l.changeColor("Жовтий");
        l.showSignal();
        l.changeColor("Зелений");
        l.showSignal();

        System.out.println("\n\nЗавдання 13: Ігровий персонаж (Player: шкода та лікування)");
        Player arten = new Player();
        arten.nickname = "arhi";
        arten.takeDamage(1);
        arten.takeDamage(50);
        arten.heal(111);
        arten.takeDamage(111);

        System.out.println("\n\nЗавдання 14: Розумна настільна лампа");
        Lamp l1 = new Lamp();
        l1.toggle();
        l1.status();
        l1.toggle();
        l1.status();

        System.out.println("\n\nЗавдання 15: Секундомір (Stopwatch)");
        Stopwatch u = new Stopwatch();
        u.tick();
        u.tick();
        u.addSeconds(999);
        u.displayTime();

        System.out.println("\n\nЗавдання 16: Офісний принтер");
        Printer printer = new Printer();
        printer.model = "ab123";
        printer.paperCount = 999;
        printer.printDocument("fdd", 500);
        printer.printDocument("tt", 600);

        System.out.println("\n\nЗавдання 17: Простий калькулятор чисел");
        SimpleCalculator calculator = new SimpleCalculator();
        calculator.divide(2, 0);
        calculator.multiply(10, 2);

        System.out.println("Завдання 18: Коло та геометричні розрахунки");
        Circle circle = new Circle();
        circle.radius = 5.0;
        System.out.println(circle.radius);
        circle.getArea();
        circle.getCircumference();

        System.out.println("\n\nЗавдання 19: Конвертер температур");
        TemperatureConverter converter = new TemperatureConverter();
        converter.celsiusToFahrenheit(25);
        converter.fahrenheitToCelsius(77);

        System.out.println("\n\nЗавдання 20: Числовий аналізатор (NumberChecker)");
        NumberChecker checker = new NumberChecker();
        System.out.println("7");
        System.out.println("  Парне? " + checker.isEven(7));
        System.out.println("  Додатне? " + checker.isPositive(7));
        System.out.println("  Просте? " + checker.isPrime(7));
        System.out.println("12");
        System.out.println("  Парне? " + checker.isEven(12));
        System.out.println("  Додатне? " + checker.isPositive(12));
        System.out.println("  Просте? " + checker.isPrime(12));
        System.out.println("-5:");
        System.out.println("  Парне? " + checker.isEven(-5));
        System.out.println("  Додатне? " + checker.isPositive(-5));
        System.out.println("  Просте? " + checker.isPrime(-5));

        System.out.println("\n\nЗавдання 21: Обмін валют (CurrencyExchange)");
        CurrencyExchange bal = new CurrencyExchange();
        double uahAmount = 10000.0;
        double usdResult = bal.toUSD(uahAmount);
        System.out.printf("Результат обміну %.2f грн: %.2f USD%n", uahAmount, usdResult);

        System.out.println("\n\nЗавдання 22: Заробітна плата співробітника");
        Employee employee = new Employee();
        employee.baseSalary = 30_000;
        employee.bonusPercentage = 15;
        employee.calculateTotalSalary();
        employee.calculateTax();

        System.out.println("\n\nЗавдання 23: Форматування та аналіз рядків");
        TextFormatter text = new TextFormatter();
        text.formatTitle("мишамак");
        text.countVowels("ємишмакусен");

        System.out.println("\n\nЗавдання 24: Клас Triangle (Трикутник)");
        Triangle tri = new Triangle();
        tri.a = 3;
        tri.b = 4;
        tri.c = 5;
        tri.getArea();
        tri.getPerimeter();
        tri.isValid();

        System.out.println("\n\nБлок 4\nЗавдання 25: Демонстрація інкапсуляції (SecretVault)");
        SecretVault vault = new SecretVault();
        System.out.println("Перевірка коду '12345': " + vault.verifyCode("12345"));
        System.out.println("Перевірка коду 'Pass123': " + vault.verifyCode("Pass123"));

        System.out.println("\n\nЗавдання 26: Обліковий запис користувача");
        UserAccount account = new UserAccount();
        account.setCredentials("mars", "supercat");
        System.out.println("Вхід з неправильними даними: " + account.login("mars", "car"));
        System.out.println("Вхід з правильними даними: " + account.login("mars", "supercat"));
        account.changePassword("car", "nuipasvord");
        account.changePassword("supercat", "nuipasvord");
        System.out.println("Вхід зі старим паролем: " + account.login("mars", "supercat"));
        System.out.println("Вхід з новим паролем: " + account.login("mars", "nuipasvord"));

        System.out.println("\n\nЗавдання 27: Банківський рахунок із захистом від овердрафту");
        BankAccount bamk = new BankAccount();
        bamk.getBalance();
        bamk.deposit(6767);
        bamk.getBalance();
        bamk.withdraw(67);
        bamk.getBalance();
        bamk.withdraw(6701);
        bamk.getBalance();

        System.out.println("\n\nЗавдання 28: Термометр та абсолютний нуль");
        Thermometer ter = new Thermometer();
        System.out.println("температура " + ter.getTemperature());
        ter.setTemperature(-2222);
        System.out.println("температура після веденя числа -2222 " + ter.getTemperature());
        ter.setTemperature(67);
        System.out.println("температура " + ter.getTemperature());

        System.out.println("\n\nЗавдання 29: Спідометр автомобіля з обмеженням швидкості");
        CarSpeedometer speedometer = new CarSpeedometer();
        speedometer.brake(4);
        speedometer.accelerate(235);
        speedometer.accelerate(1111);

        System.out.println("\n\nЗавдання 30: Персона та використання слова this");
        Person r = new Person();
        Person r2 = new Person();
        r.setName("миша");
        r.setAge(21);
        r2.setName("гриша");
        r2.setAge(24);
        r.printSummary();
        r2.printSummary();

        System.out.println("\n\nЗавдання 31: Дисконтна картка з накопичувальною знижкою");
        DiscountCard card = new DiscountCard();
        card.addPurchase(3000);
        card.printCardInfo();
        card.addPurchase(4000);
        card.printCardInfo();

        System.out.println("\n\nЗавдання 32: Розумний кодовий замок (SmartDoorLock)");
        SmartDoorLock door = new SmartDoorLock();
        door.enterPin(1);
        door.enterPin(2);
        door.enterPin(9);
        door.enterPin(434);


        System.out.println("\n\nБлок 5\nЗавдання 33: Журнал оцінок студента (GradeBook)");
        GradeBook book = new GradeBook();
        int[] ar = {85, 92, 78, 96, 65};
        book.setData("ara", ar);
        System.out.println("Середній бал: " + book.getAverage());
        System.out.println("Найвища оцінка: " + book.getHighestGrade());
        System.out.println("Найнижча оцінка: " + book.getLowestGrade());

        System.out.println("\n\nЗавдання 34: Статистичний аналізатор масиву (ArrayStats)");
        ArrayStats stats = new ArrayStats();
        int[] myNumbers = {4, 7, 12, 19, -5, 8, 22, 0, 15, 3};
        stats.setNumbers(myNumbers);
        System.out.println("парні " + stats.countEvens());
        System.out.println("непарні " + stats.countOdds());
        System.out.println("сума  " + stats.calculateSum());

        System.out.println("\n\nЗавдання 35: Кошик покупок супермаркету (ShoppingCart)");
        ShoppingCart cart = new ShoppingCart();
        cart.addItem(200.00);
        cart.addItem(50.00);
        cart.addItem(750.00);
        System.out.println("Початковий чек:");
        cart.printReceipt();
        cart.applyDiscount(15);
        cart.printReceipt();

        System.out.println("\n\nЗавдання 36: Щоденник температур тижня (TemperatureTracker)");
        TemperatureTracker tracker = new TemperatureTracker();
        double[] autumnWeeks = {12.4, 15.1, 14.8, 17.5, 11.0, 9.5, 13.0};
        tracker.setTemps(autumnWeeks);
        tracker.printWeeklyReport();
        double ber = 13.0;
        int dar = tracker.countDaysAbove(ber);
        System.out.println("Кількість днів, коли було тепліше ніж " + ber + "°C: " + dar);

        System.out.println("\n\nЗавдання 37: Шукач елементів (ArraySearcher)");
        ArraySearcher searcher = new ArraySearcher();
        int[] myData = {10, 45, 82, 19, 5, 33};
        searcher.setData(myData);
        int existingTarget = 19;
        System.out.println("Шукаємо число " + existingTarget + ":");
        System.out.println("Чи є в масиві? " + searcher.contains(existingTarget));
        System.out.println("Його індекс: " + searcher.findIndex(existingTarget));
        int missingTarget = 99;
        System.out.println("Шукаємо число " + missingTarget + ":");
        System.out.println("Чи є в масиві? " + searcher.contains(missingTarget));
        System.out.println("Його індекс: " + searcher.findIndex(missingTarget));

        System.out.println("\n\nЗавдання 38: Тривимірний вектор (Vector3D) на базі масиву");
        Vector3D vector = new Vector3D();
        vector.setCoords(2, 3, 6);
        System.out.print("Початковий вектор: ");
        vector.printVector();
        double magnitude = vector.getMagnitude();
        System.out.println("Довжина вектора: " + magnitude);
        double scalar = 2.0;
        vector.multiplyByScalar(scalar);
        System.out.println("Вектор після множення на " + scalar + ":");
        vector.printVector();

        System.out.println("\n\nЗавдання 39: Двовимірна таблиця чисел (Matrix2D)");
        Matrix2D matrixObj = new Matrix2D();

        // 2. Створюємо матрицю 3х3 з довільними числами
        int[][] my3x3Matrix = {
                {3, 5, 2},
                {1, 4, 7},
                {6, 0, 8},
        };
        matrixObj.setGrid(my3x3Matrix);
        System.out.println("Ваша матриця 3х3:");
        matrixObj.printMatrix();
        System.out.println("-----------------------------------");
        System.out.println("Сума всіх чисел матриці: " + matrixObj.getTotalSum());
        int targetRow = 1;
        System.out.println("Сума елементів рядка з індексом " + targetRow + ": " + matrixObj.getRowSum(targetRow));
    }
}