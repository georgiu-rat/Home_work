package semester1.practice06;

public class TemperatureConverter {
    public double celsiusToFahrenheit(double c){
        double f =c*1.8+32;
        System.out.println(f);
        return f;
    }
    public double fahrenheitToCelsius(double f){
        double c =(f-32)/1.8;
        System.out.println(c);
        return c;
    }
}
