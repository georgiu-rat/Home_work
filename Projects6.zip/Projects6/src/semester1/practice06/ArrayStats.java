package semester1.practice06;

public class ArrayStats {
    private int[] numbers;
    public void setNumbers(int[] nums){
        this.numbers = nums;
    }
    public int countEvens(){
        if (numbers == null) return 0;

        int count = 0;
        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] % 2 == 0) {
                count++;
            }
        }
        return count;
    }
    public int countOdds(){
        if (numbers == null) return 0;
        int count = 0;
        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] % 2 != 0) {
                count++;
            }
        }
        return count;
    }
    public int calculateSum(){
        if (numbers == null) return 0;
        int sum = 0;
        for (int i = 0; i < numbers.length; i++) {
            sum += numbers[i];
        }
        return sum;
    }
}
