package semester1.practice06;

public class Vector3D {
    private double[] coords = new double[3];
    public void setCoords(double x, double y, double z) {
        this.coords[0] = x;
        this.coords[1] = y;
        this.coords[2] = z;
    }
    public double getMagnitude() {
        double x = coords[0];
        double y = coords[1];
        double z = coords[2];
        return Math.sqrt(x * x + y * y + z * z);
    }
    public void multiplyByScalar(double scalar) {
        for (int i = 0; i < coords.length; i++) {
            coords[i] *= scalar;
        }
    }
    public void printVector() {
        System.out.printf("(%.1f, %.1f, %.1f)%n", coords[0], coords[1], coords[2]);
    }
}
