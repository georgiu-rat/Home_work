package semester1.practice06;

public class SimpleCalculator {
    public int add(int a, int b){
        System.out.println(a+b);
        return a+b;
    }
    public int subtract(int a, int b){
        System.out.println(a-b);
        return a-b;
    }
    public int multiply(int a, int b){
        System.out.println(a*b);
        return a*b;
    }
    public double divide(int a, int b){
        if (b!=0){
        System.out.println(a/b);}
        else {
            System.out.println("b=0");
        }
        return 0.0;
    }
}
