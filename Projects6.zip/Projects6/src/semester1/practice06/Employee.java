package semester1.practice06;

public class Employee {
    public String name;
    public double baseSalary;
    public double bonusPercentage;
    public double calculateTotalSalary(){
        double cal=baseSalary*(1+bonusPercentage/100);
        System.out.println(cal);
        return cal;
    }
    public double calculateTax(){
        double taxi=(baseSalary*(1+bonusPercentage/100)/19.5*100);
        System.out.println(taxi);
        return taxi;
    }

}
