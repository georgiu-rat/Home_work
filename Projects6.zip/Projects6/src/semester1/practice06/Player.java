package semester1.practice06;

public class Player {
    public String nickname;
    public int health=100;
    public void takeDamage(int damage){
        health-=damage;
        if (damage>=100){
            damage=100;
        }
        System.out.println("-"+damage+" hp");
        if (health<=0){
            health=0;
            System.out.println(nickname+" загинув!");
        }
    }
    public void heal(int amount){
        health+=amount;
        if (amount>=100){
            amount=100;
        }
        System.out.println("+"+amount+" hp");
        if (health>=100){
            health=100;
        }
    }

}
