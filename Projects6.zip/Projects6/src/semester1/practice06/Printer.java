package semester1.practice06;

public class Printer {
    public String model;
    int paperCount;
    public void printDocument(String title, int pages){
        if (pages<paperCount){
            paperCount-=pages;
            System.out.println("друк успішно");
        }
        else {
            System.out.println("Помилка: Недостатньо паперу в принтері "+model);
        }
    }
}
