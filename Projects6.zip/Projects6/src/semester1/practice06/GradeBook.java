package semester1.practice06;

public class GradeBook {
    private String studentName;
    private int[] grades;
    public void setData(String name, int[] g){
        this.studentName = name;
        this.grades = g;
    }
    public double getAverage(){
        if (grades == null || grades.length == 0) {
            return 0;
        }
        int sum = 0;
        for (int i = 0; i < grades.length; i++) {
            sum += grades[i];
        }
        return (double) sum / grades.length;
    }
    public int getHighestGrade(){
        if (grades == null || grades.length == 0) {
            return 0;
        }
        int max = grades[0];
        for (int i = 1; i < grades.length; i++) {
            if (grades[i] > max) {
                max = grades[i];
            }
        }
        return max;
    }
    public int getLowestGrade(){
        if (grades == null || grades.length == 0) {
            return 0;
        }
        int min = grades[0];
        for (int i = 1; i < grades.length; i++) {
            if (grades[i] < min) {
                min = grades[i];
            }
        }
        return min;
    }
}
