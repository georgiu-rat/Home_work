package semester1.practice06;

public class ShoppingCart {
    private double[] itemPrices = new double[10];
    private int count = 0;

    public void addItem(double price) {
        if (count >= itemPrices.length) {
            System.out.println("Кошик переповнений! Неможливо додати товар за ціною " + price);
            return;
        }
        itemPrices[count] = price;
        count++;
        System.out.println("Товар за ціною " + price + " успішно додано. Всього в кошику: " + count);
    }

    public double getTotalCost() {
        double total = 0;
        for (int i = 0; i < count; i++) {
            total += itemPrices[i];
        }
        return total;
    }

    public void applyDiscount(double percent) {
        if (percent < 0 || percent > 100) {
            System.out.println("Некоректний відсоток знижки!");
            return;
        }
        for (int i = 0; i < count; i++) {
            itemPrices[i] = itemPrices[i] * (1 - percent / 100);
        }
        System.out.print("викорствовуємо знижку "+percent+"% ");
    }

    public void printReceipt() {
        if (count == 0) {
            System.out.println("Кошик порожній.");
            return;
        }
        System.out.println("чек");
        for (int i = 0; i < count; i++) {
            System.out.printf("Товар %d: %.2f грн%n", (i + 1), itemPrices[i]);
        }
        System.out.printf("до сплати: %.2f грн%n", getTotalCost());
    }
}