package semester1.practice06;

public class Lamp {
    boolean isOn;
    public void turnOn(){
        isOn = true;
    }
    public void turnOff(){
        isOn = false;
    }
    public void toggle(){
        isOn=!isOn;
    }
    public void status(){
        if (isOn = true) {
            System.out.println("Лампа світить");
        }
        else {
            System.out.println("Лампа вимкнена");
        }
    }
}
