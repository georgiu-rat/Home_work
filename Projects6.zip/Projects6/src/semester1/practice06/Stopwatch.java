package semester1.practice06;

public class Stopwatch {
    public int seconds;
    public void tick(){
        seconds++;
    }
    public void addSeconds(int s){
        seconds+=s;
    }
    public void displayTime(){
        int minutes = seconds / 60;
        int sekuna = seconds % 60;
        String time = String.format("%02d:%02d", minutes, sekuna);
        System.out.println("Час на секундомірі: " + time);
    }

}
