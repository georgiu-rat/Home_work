package semester1.practice06;

public class UserAccount {
    private String username;
    private String password;
    public void setCredentials(String u, String p){
        this.username = u;
        this.password = p;
    }
    public boolean login(String enteredUser, String enteredPass) {
        return this.username.equals(enteredUser) && this.password.equals(enteredPass);
    }
    public void changePassword(String oldPass, String newPass){

    }
}
