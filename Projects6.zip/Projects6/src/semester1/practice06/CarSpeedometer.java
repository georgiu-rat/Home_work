package semester1.practice06;

public class CarSpeedometer {
    private int speed = 0;
    public void accelerate(int delta){
        if (speed>240){
            speed+=delta;
            System.out.println("+"+delta);

        }
        else {
            speed=240;
            System.out.println("240");
        }
    }
    public void brake(int delta){
        if (speed<0){
            speed-=delta;
            System.out.println("-"+delta);
        }
        else {
            speed=0;
            System.out.println("0");
        }
    }
    public int getSpeed(){
        return speed;
    }
}
