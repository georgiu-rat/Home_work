package semester1.practice06;

public class Triangle {
    public double a;
    public double b;
    public double c;
    public boolean isValid(){
        if (a <= 0 || b <= 0 || c <= 0) {
            System.out.println("валідне");
            return false;
        }
        boolean rez=(a + b > c) && (a + c > b) && (b + c > a);
        System.out.println(rez);
        return rez;
    }
    public double getPerimeter(){
        System.out.println(a+b+c);
        return (a+b+c);
    }
    public double getArea(){
        double p=(a+b+c)/2;
        double s=Math.sqrt(p*(p-a)*(p-b)*(p-c));
        return s;
    }
}
