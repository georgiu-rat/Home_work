package semester1.practice06;

public class BankAccount {
    private String accountNumber;
    private double balance;
    public void deposit(double amount){
        if (amount > 0){
            System.out.println("поповненя дозволено");
            balance+=amount;
        }
    }
    public boolean withdraw(double amount){
        if (amount > balance){
            System.out.println("відмова");
        }
        else {
            System.out.println("дозволено");
            balance-=amount;
        }
        return false;
    }
    public double getBalance(){
        System.out.println(balance);
        return balance;
    }
}
