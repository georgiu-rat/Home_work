package semester1.practice06;

public class Circle {
    public double radius;
    public double getArea(){
        double area = Math.PI * Math.pow(radius, 2);
        System.out.println(area);
        return area;
    }
    public double getCircumference(){
        double Circumference=Math.PI*2*radius;
        System.out.println(Circumference);
        return Circumference;

    }
}
