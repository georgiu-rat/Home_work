package semester1.practice06;

public class Counter {
    public int count;
    public void increment() {
        count++; // або: count = count + 1;
    }
    public void decrement() {
        count--;
    }
    public void reset() {
        count = 0;
    }
    public void printCount() {
        System.out.println("Поточне значення лічильника: " + count);
    }
}
