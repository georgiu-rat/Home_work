package semester1.practice06;

public class TemperatureTracker {
    private double[] dailyTemps = new double[7];

    public void setTemps(double[] temps) {
        this.dailyTemps = temps;
    }

    public int countDaysAbove(double threshold) {
        if (dailyTemps == null) return 0;
        int count = 0;
        for (int i = 0; i < dailyTemps.length; i++) {
            if (dailyTemps[i] > threshold) {
                count++;
            }
        }
        return count;
    }

    public void printWeeklyReport() {
        if (dailyTemps == null || dailyTemps.length == 0) {
            System.out.println("Дані про температуру відсутні.");
            return;
        }
        double maxTemp = dailyTemps[0];
        for (int i = 1; i < dailyTemps.length; i++) {
            if (dailyTemps[i] > maxTemp) {
                maxTemp = dailyTemps[i];
            }
        }
        System.out.println("=== ЗВІТ ЗА ТИЖДЕНЬ ===");
        for (int i = 0; i < dailyTemps.length; i++) {
            System.out.printf("День %d: %.1f°C", (i + 1), dailyTemps[i]);
            if (dailyTemps[i] == maxTemp) {
                System.out.print(" <--- НАЙТЕПЛІШИЙ ДЕНЬ!");
            }
            System.out.println();
        }
        System.out.println("=======================");
    }
}
