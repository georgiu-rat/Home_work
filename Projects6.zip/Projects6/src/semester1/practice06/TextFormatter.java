package semester1.practice06;

public class TextFormatter {
    public String formatTitle(String text){
        System.out.println("***"+text+"***");
        return text;
    }
    public int countVowels(String text) {
        if (text == null || text.isEmpty()) {
            return 0;
        }
        int count = 0;
        String lowerText = text.toLowerCase();
        String vowels = "аоуеиіяюєїaeiou";
        for (int i = 0; i < lowerText.length(); i++) {
            char currentLetter = lowerText.charAt(i);
            if (vowels.indexOf(currentLetter) != -1) {
                count++;
            }
        }
        System.out.println(count);
        return count;
    }

}
