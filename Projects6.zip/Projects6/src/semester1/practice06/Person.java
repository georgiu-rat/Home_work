package semester1.practice06;

public class Person {
    private String name;
    private int age;
    public void setName(String name){
        this.name = name;
    }
    public void setAge(int age){
        if (age>0 && age<120){
            this.age=age;
        }
        else {
            System.out.println("вік не валідний");
        }
    }
    public void printSummary(){
        System.out.println(name);
        System.out.println(age);

    }

}
