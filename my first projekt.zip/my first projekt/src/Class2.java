public class Class2 {
    public static void main(String[] args){
       System.out.print("\nJava - ");
       System.out.print("це обєктоно-орієнтована ");
       System.out.print("мова програмуваня.\n\n");

       System.out.print("Вчитися, ");
       System.out.print("вчитися, ");
       System.out.print("практикватися, ");
       System.out.println("перемагати!\n\n");

       System.out.print("Сьгодні ");
       System.out.print("чудовий день ");
       System.out.println("для програмуваня");
       System.out.println("Заватра буде ще краще\n\n");

       System.out.print("[ID]");
       System.out.print("[Ім'я]");
       System.out.print("[Статус]");

        System.out.print("\n\nЗавантаження: [           ] 0%\n");
        System.out.print("Завантаження: [=====>     ] 50%\n");
        System.out.print("Завантаження: [===========] 100%\n\n");

        System.out.print("[x]");
        System.out.println(" Встановити JDK та IntelliJ IDEA");
        System.out.print("[ ]");
        System.out.print(" Розв'язати 40 завдань практики");

        System.out.print("\n\nМісто: Київ | Тел: +380000000000 | Email: student@univ.edu\n\n");
    }
}
