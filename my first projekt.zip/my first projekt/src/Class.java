public class Class {
    public static void main(String[] args){
       System.out.println("Helo\n");
       System.out.println("Привіт мене звати (my name)\nя починаю вивчати Java\n\n");
       System.out.println("Порядок у коді — порядок у думках.\n\n");
       System.out.println("Студент: Іван Коваленко\n" + "Група: КН-101\n" + "Спеціальність: Комп'ютерні науки\n\n");
       System.out.println("Початок програми\n\nКінець програма\n\n");

        System.out.println("Звіт про виконання роботи\n" + "-------------------------\n\n");
        System.out.println("******\n" + "*JAVA*\n" + "******\n\n");

        System.out.println(1);
        System.out.println(2);
        System.out.println(3);
        System.out.println(4);
        System.out.println(5);
    }


}
