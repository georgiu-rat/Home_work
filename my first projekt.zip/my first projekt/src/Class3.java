public class Class3 {
    public static void main(String[] args){
        System.out.print("Україна\nмісто Львів\nвулиця Степана Бандери, 12\n\n");

        System.out.print("Реве та стогне Дніпр широкий,\nСердитий вітер завива,\nДодолу верби гне високі,\nГорами хвилю підійма.\n\n");

        System.out.print("№\tТовар\tКількість\tЦіна\n1\tзошит\t3\t\t45\tгрн\n1\tРучка\t2\t\t30\tгрн\n\n");

        System.out.print("Пара\tЧас\t\tПредмет\n1\t08:30\t\tВища математика\n2\t10:10\t\tОснови програмування\n3\t11:50\t\tАнглійська мова\n\n");

        System.out.print("Сократ сказав: \"Я знаю тільки те, що я нічого не знаю\".\n\n");

        System.out.println("Мій улюблений фантастичний фільм — \"Інтерстеллар\" режисера Крістофера Нолана.\n");

        System.out.println("C:\\Users\\Student\\Desktop\\JavaProjects\\Practice01\\Main.java\n");

        System.out.println("Java\n\tце\n\t\tпросто\n\t\t\tта\n\t\t\t\tпотужно\n");
    }
}
