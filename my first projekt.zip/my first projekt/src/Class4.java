public class Class4 {
    public static void main(String[] args){
       System.out.println(1);
       System.out.println(-123);
       System.out.println(0);
       System.out.println("0.333(3)\n");

       System.out.println("24 + 25\n");
       System.out.println(49);
       System.out.println();
       System.out.println("Не мій вік");
       System.out.println(2026 - 2006);

       System.out.println("Кількість секунд в добі");
       System.out.println(60*60*24);
       System.out.println();

       System.out.println("23\\6 у цілих числах дорівнює:");
       System.out.print(23/6);
       System.out.println("\n");
       System.out.print(23.0/6.0);
       System.out.println("\n");

       System.out.print("Результати виразу ");
       System.out.print((10+5)*4-20/2);

       System.out.println("Периметр кімнати (м):\n" + (6+4)*2);
       System.out.println("Площа кімнати (кв. м):\n" + 6*4);



    }
}
