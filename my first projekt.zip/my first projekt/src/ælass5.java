public class Сlass5 {
    public static void main(String[] args){
        System.out.println("*****\n*****\n*****\n\n");

        System.out.println("*****\n*\t*\n*\t*\n*****\n\n");

        System.out.println("#\n##\n###\n####\n#####\n\n");

        System.out.println("[o_o]\n/|\t|\\\nd\tb\n\n");

        System.out.println("  *\n ***\n*****\n |||\n\n");

        System.out.println("  /\\\n /  \\\n/____\\\n| [] |\n|____|\n\n");

        System.out.println("*****\n*\n*\n*\n\n");

        System.out.println("+------------------------------------+\n" +
                           "|             STORE ЧЕК              |\n" +
                           "+------------------------------------+\n" +
                           "| Предмет       Шт            Ціна   |\n" +
                           "| пацюк         1             400 грн|\n" +
                           "| сир           1 кг          150    |\n" +
                           "+------------------------------------+\n" +
                           "| До сплати (грн):                   |\n" +
                           "| 550                                |\n" +
                           "+------------------------------------+\n" +
                           "|      Дякуємо за покупку!           |\n" +
                           "+------------------------------------+");



    }
}
