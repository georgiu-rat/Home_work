package semester1.practice10.task_26;

public class WiredPrinter {
    private final String model;
    public WiredPrinter(String model) {
        this.model = model;}
    public String getModel() {
        return model;}
}
