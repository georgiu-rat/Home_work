package semester1.practice10.task_26;

public class DesktopMonitor {
    private final String model;
    public DesktopMonitor(String model) {
        this.model = model;}
    public String getModel() {
        return model;}
}
