package semester1.practice10.task_26;

public interface Rechargeable {
    void chargeToFull();
    int getBatteryLevel();
}
