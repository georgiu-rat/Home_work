package semester1.practice10.task_26;

public class Laptop implements Rechargeable {
    private int batteryPercent = 15;
    @Override
    public void chargeToFull() {
        this.batteryPercent = 100;
        System.out.println("[Ноутбук] Заряджено до 100%.");}
    @Override
    public int getBatteryLevel() {
        return batteryPercent;}
}
