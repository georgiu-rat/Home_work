package semester1.practice10.task_26;

public class ElectricScooter implements Rechargeable {
    private int batteryPercent = 30;
    @Override
    public void chargeToFull() {
        this.batteryPercent = 100;
        System.out.println("[Електросамокат] Заряджено до 100%.");}
    @Override
    public int getBatteryLevel() {
        return batteryPercent;}
}