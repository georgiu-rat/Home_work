package semester1.practice10.task_23;

public interface Calibratable {
    void calibrate(double referenceValue);
}
