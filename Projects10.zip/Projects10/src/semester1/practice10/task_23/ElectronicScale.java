package semester1.practice10.task_23;

public class ElectronicScale extends AbstractLabDevice implements Calibratable, SelfDiagnostic {
    private double currentCalibrationOffset;
    public ElectronicScale(String inventoryCode) {
        super(inventoryCode);
        this.currentCalibrationOffset = 0.0;}
    @Override
    public void performMeasurement() {
        System.out.printf("[Ваги %s] Зважування виконано успішно.%n", getInventoryCode());}
    @Override
    public void calibrate(double referenceValue) {
        this.currentCalibrationOffset = referenceValue - 100.0;
        System.out.printf("[Ваги %s] Калібрування за еталоном %.2f завершено.%n", getInventoryCode(), referenceValue);}
    @Override
    public boolean runSelfCheck() {
        System.out.printf("[Ваги %s] Самодіагностика датчиків... Статус: ОК.%n", getInventoryCode());
        return true;}
}
