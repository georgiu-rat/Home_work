package semester1.practice10.task_23;

public abstract class AbstractLabDevice {
    private final String inventoryCode;
    public AbstractLabDevice(String inventoryCode) {
        this.inventoryCode = inventoryCode;}
    public String getInventoryCode() {
        return inventoryCode;}
    public abstract void performMeasurement();
}
