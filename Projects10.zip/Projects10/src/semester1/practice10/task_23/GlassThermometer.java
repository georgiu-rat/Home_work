package semester1.practice10.task_23;

public class GlassThermometer extends AbstractLabDevice {
    public GlassThermometer(String inventoryCode) {
        super(inventoryCode);}
    @Override
    public void performMeasurement() {
        System.out.printf("[Термометр %s] Вимірювання температури за шкалою ртутного стовпчика.%n", getInventoryCode());}
}
