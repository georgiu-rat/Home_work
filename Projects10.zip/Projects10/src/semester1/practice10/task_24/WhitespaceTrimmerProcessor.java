package semester1.practice10.task_24;

public class WhitespaceTrimmerProcessor implements TextProcessor {
    @Override
    public String process(String text) {
        if (text == null) return null;
        return text.trim().replaceAll("\\s+", " ");
    }
}
