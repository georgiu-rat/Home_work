package semester1.practice10.task_24;

public interface TextProcessor {
    String process(String text);
}
