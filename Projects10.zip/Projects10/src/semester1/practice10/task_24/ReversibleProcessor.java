package semester1.practice10.task_24;

public interface ReversibleProcessor extends TextProcessor {
    String reverseProcess(String text);
}
