package semester1.practice10.task_24;

public class CaesarCipherProcessor implements ReversibleProcessor {
    private final int shift;
    public CaesarCipherProcessor(int shift) {
        this.shift = shift;}
    @Override
    public String process(String text) {
        if (text == null) return null;
        StringBuilder sb = new StringBuilder();
        for (char c : text.toCharArray()) {
            sb.append((char) (c + shift));}
        return sb.toString();}
    @Override
    public String reverseProcess(String text) {
        if (text == null) return null;
        StringBuilder sb = new StringBuilder();
        for (char c : text.toCharArray()) {
            sb.append((char) (c - shift));}
        return sb.toString();}
}
