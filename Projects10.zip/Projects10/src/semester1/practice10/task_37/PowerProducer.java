package semester1.practice10.task_37;

public interface PowerProducer {
    double produceMw();
    String getStationId();
}
