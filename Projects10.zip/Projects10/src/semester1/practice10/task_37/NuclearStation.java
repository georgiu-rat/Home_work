package semester1.practice10.task_37;

public class NuclearStation extends AbstractPowerStation {
    private final double baseCapacityMw;
    public NuclearStation(String stationId, double baseCapacityMw) {
        super(stationId);
        this.baseCapacityMw = baseCapacityMw;}
    @Override
    public double produceMw() {
        return baseCapacityMw;}
}