package semester1.practice10.task_37;

public class HydroDamStation extends AbstractPowerStation implements WeatherDependent {
    private final double nominalCapacityMw;
    private double waterFlowFactor = 1.0; // повноводність
    public HydroDamStation(String stationId, double nominalCapacityMw) {
        super(stationId);
        this.nominalCapacityMw = nominalCapacityMw;}
    @Override
    public void updateWeatherCondition(double waterFactor) {
        this.waterFlowFactor = Math.max(0.0, Math.min(1.5, waterFactor));}
    @Override
    public double produceMw() {
        return nominalCapacityMw * waterFlowFactor;}
}