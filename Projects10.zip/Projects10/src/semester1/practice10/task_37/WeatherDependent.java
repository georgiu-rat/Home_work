package semester1.practice10.task_37;

public interface WeatherDependent {
    void updateWeatherCondition(double weatherFactor);
}
