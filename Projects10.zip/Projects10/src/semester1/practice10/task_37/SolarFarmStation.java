package semester1.practice10.task_37;

public class SolarFarmStation extends AbstractPowerStation implements WeatherDependent {
    private final double maxCapacityMw;
    private double weatherFactor = 1.0;
    public SolarFarmStation(String stationId, double maxCapacityMw) {
        super(stationId);
        this.maxCapacityMw = maxCapacityMw;}
    @Override
    public void updateWeatherCondition(double weatherFactor) {
        this.weatherFactor = Math.max(0.0, Math.min(1.0, weatherFactor));}
    @Override
    public double produceMw() {
        return maxCapacityMw * weatherFactor;}
}
