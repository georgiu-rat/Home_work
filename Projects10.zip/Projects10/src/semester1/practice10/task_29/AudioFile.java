package semester1.practice10.task_29;

public class AudioFile extends MediaItem {
    private final int bitrateKbps;
    public AudioFile(String title, double sizeMb, int bitrateKbps) {
        super(title, sizeMb);
        this.bitrateKbps = bitrateKbps;}
    public boolean isLossless() {
        return bitrateKbps >= 1000;}
}
