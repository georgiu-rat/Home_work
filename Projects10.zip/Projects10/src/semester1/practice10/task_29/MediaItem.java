package semester1.practice10.task_29;

public abstract class MediaItem {
    private final String title;
    private final double sizeMb;
    public MediaItem(String title, double sizeMb) {
        this.title = title;
        this.sizeMb = sizeMb;}
    public String getTitle() {
        return title;}
    public double getSizeMb() {
        return sizeMb;}
}
