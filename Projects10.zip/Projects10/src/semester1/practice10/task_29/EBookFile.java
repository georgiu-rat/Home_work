package semester1.practice10.task_29;

public class EBookFile extends MediaItem {
    private final int pageCount;
    public EBookFile(String title, double sizeMb, int pageCount) {
        super(title, sizeMb);
        this.pageCount = pageCount;}
    public int getPageCount() {
        return pageCount;}
}
