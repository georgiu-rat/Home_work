package semester1.practice10.task_29;

public class VideoFile extends MediaItem {
    private final int resolutionHeight;
    private final int durationSec;
    public VideoFile(String title, double sizeMb, int resolutionHeight, int durationSec) {
        super(title, sizeMb);
        this.resolutionHeight = resolutionHeight;
        this.durationSec = durationSec;}
    public boolean is4K() {
        return resolutionHeight >= 2160;}
}
