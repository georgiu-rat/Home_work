package semester1.practice10.task_19;

public interface DividendPaying {
    double calculateAnnualDividend();
}
