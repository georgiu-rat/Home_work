package semester1.practice10.task_19;

public class TechGrowthStock extends AbstractFinancialInstrument implements Tradable {
    private double currentPriceUah;
    public TechGrowthStock(String ticker, int quantity, double currentPriceUah) {
        super(ticker, quantity);
        this.currentPriceUah = currentPriceUah;}
    @Override
    public double getMarketValueUah() {
        return quantity * currentPriceUah;}
    @Override
    public boolean buy(int qty) {
        if (qty > 0) {
            this.quantity += qty;
            return true;}
        return false;}
    @Override
    public boolean sell(int qty) {
        if (qty > 0 && this.quantity >= qty) {
            this.quantity -= qty;
            return true;}
        return false;}
}