package semester1.practice10.task_19;

public class FixedTermDeposit extends AbstractFinancialInstrument implements DividendPaying {
    private final double interestRate;
    public FixedTermDeposit(String ticker, double principalUah, double interestRate) {
        super(ticker, (int) principalUah);
        this.interestRate = interestRate;}
    @Override
    public double getMarketValueUah() {
        return quantity;}
    @Override
    public double calculateAnnualDividend() {
        return quantity * interestRate;}
}
