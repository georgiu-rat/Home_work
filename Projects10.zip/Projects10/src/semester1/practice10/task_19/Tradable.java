package semester1.practice10.task_19;

public interface Tradable {
    boolean buy(int qty);
    boolean sell(int qty);
}
