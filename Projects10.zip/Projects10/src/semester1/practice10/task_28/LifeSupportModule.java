package semester1.practice10.task_28;

public class LifeSupportModule extends ShipModule {
    public LifeSupportModule(String name, boolean damaged) {
        super(name, damaged);}
    public double getOxygenPercent() {
        return 98.5;}}
