package semester1.practice10.task_28;

public class ShieldGenerator extends ShipModule {
    public ShieldGenerator(String name, boolean damaged) {
        super(name, damaged);}
    public void rechargeShields(int megajoules) {
        System.out.printf("   └─ [Щити] Генератор '%s' успішно перезаряджено на %d МДж.%n", getName(), megajoules);}
}
