package semester1.practice10.task_28;

public abstract class ShipModule {
    private final String name;
    protected boolean damaged;
    public ShipModule(String name, boolean damaged) {
        this.name = name;
        this.damaged = damaged;}
    public String getName() {
        return name;}
    public boolean isDamaged() {
        return damaged;}
}
