package semester1.practice10.task_28;

public class WarpDrive extends ShipModule {
    public WarpDrive(String name, boolean damaged) {
        super(name, damaged);}
    public boolean checkAntimatterContainment() {
        System.out.printf("   └─ [Варп-двигун] Камера антиматерії '%s': утримання стабільне.%n", getName());
        return true;}
}
