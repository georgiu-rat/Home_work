package semester1.practice10.task_21;

public interface ElectricPowered {
    double getBatteryCapacityKwh();
}
