package semester1.practice10.task_21;

public class CargoPassengerVan extends AbstractVehicle implements CargoCarrier, PassengerCarrier {
    private final double maxPayloadTons;
    private final int seatCount;
    public CargoPassengerVan(String plateNumber, double mileageKm, double maxPayloadTons, int seatCount) {
        super(plateNumber, mileageKm);
        this.maxPayloadTons = maxPayloadTons;
        this.seatCount = seatCount;}
    @Override
    public double getMaxPayloadTons() {
        return maxPayloadTons;}
    @Override
    public int getSeatCount() {
        return seatCount;}
}
