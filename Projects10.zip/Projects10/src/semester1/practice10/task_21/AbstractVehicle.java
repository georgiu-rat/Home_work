package semester1.practice10.task_21;

public abstract class AbstractVehicle {
    private final String plateNumber;
    protected double mileageKm;
    public AbstractVehicle(String plateNumber, double mileageKm) {
        this.plateNumber = plateNumber;
        this.mileageKm = mileageKm;}
    public String getPlateNumber() {
        return plateNumber;}
    public double getMileageKm() {
        return mileageKm;}
}
