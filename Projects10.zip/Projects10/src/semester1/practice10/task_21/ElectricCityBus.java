package semester1.practice10.task_21;

public class ElectricCityBus extends AbstractVehicle implements PassengerCarrier, ElectricPowered {
    private final int seats;
    private final int totalCapacity;
    private final double batteryCapacityKwh;
    public ElectricCityBus(String plateNumber, double mileageKm, int seats, double batteryCapacityKwh) {
        super(plateNumber, mileageKm);
        this.seats = seats;
        this.totalCapacity = seats + 40;
        this.batteryCapacityKwh = batteryCapacityKwh;}
    @Override
    public int getSeatCount() {
        return totalCapacity;}
    @Override
    public double getBatteryCapacityKwh() {
        return batteryCapacityKwh;}
}
