package semester1.practice10.task_21;

public class DieselDumpTruck extends AbstractVehicle implements CargoCarrier {
    private final double maxPayloadTons;
    public DieselDumpTruck(String plateNumber, double mileageKm, double maxPayloadTons) {
        super(plateNumber, mileageKm);
        this.maxPayloadTons = maxPayloadTons;}
    @Override
    public double getMaxPayloadTons() {
        return maxPayloadTons;}
}
