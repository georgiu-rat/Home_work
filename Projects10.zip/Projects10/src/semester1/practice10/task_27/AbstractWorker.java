package semester1.practice10.task_27;

public abstract class AbstractWorker {
    private final String fullName;
    protected final double baseSalaryUah;
    public AbstractWorker(String fullName, double baseSalaryUah) {
        this.fullName = fullName;
        this.baseSalaryUah = baseSalaryUah;}
    public String getFullName() {
        return fullName;}
    public double getBaseSalaryUah() {
        return baseSalaryUah;}
}