package semester1.practice10.task_27;

public interface BonusEligible {
    double calculateQuarterBonus();
}
