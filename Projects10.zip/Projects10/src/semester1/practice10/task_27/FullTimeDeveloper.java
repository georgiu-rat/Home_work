package semester1.practice10.task_27;

public class FullTimeDeveloper extends AbstractWorker implements BonusEligible, MedicalInsured {
    public FullTimeDeveloper(String fullName, double baseSalaryUah) {
        super(fullName, baseSalaryUah);}
    @Override
    public double calculateQuarterBonus() {
        return baseSalaryUah * 0.5;}
    @Override
    public double getInsuranceCoverage() {
        return 50000.0;}
}
