package semester1.practice10.task_27;

public class FopContractor extends AbstractWorker {
    public FopContractor(String fullName, double baseSalaryUah) {
        super(fullName, baseSalaryUah);}
}
