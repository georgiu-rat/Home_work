package semester1.practice10.task_27;

public class InternStudent extends AbstractWorker implements BonusEligible {
    public InternStudent(String fullName, double baseSalaryUah) {
        super(fullName, baseSalaryUah);}
    @Override
    public double calculateQuarterBonus() {
        return 3000.0;}
}
