package semester1.practice10.task_22;

public class PaladinCaptain extends AbstractMilitaryUnit implements RangedAttacker, FieldHealer {
    private final int attackRange;
    public PaladinCaptain(String unitName, int hp, int attackRange) {
        super(unitName, hp);
        this.attackRange = attackRange;}
    @Override
    public int getMoveSpeed() {
        return 3;}
    @Override
    public int getAttackRange() {
        return attackRange;}
    @Override
    public int fireShot() {
        return 45;}
    @Override
    public int healAlly() {
        return 40;}
}
