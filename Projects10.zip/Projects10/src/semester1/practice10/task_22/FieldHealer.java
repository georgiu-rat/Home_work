package semester1.practice10.task_22;

public interface FieldHealer {
    int healAlly();
}
