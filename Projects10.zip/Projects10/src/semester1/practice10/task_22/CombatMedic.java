package semester1.practice10.task_22;

public class CombatMedic extends AbstractMilitaryUnit implements FieldHealer {
    public CombatMedic(String unitName, int hp) {
        super(unitName, hp);}
    @Override
    public int getMoveSpeed() {
        return 4;}
    @Override
    public int healAlly() {
        return 50;}
}
