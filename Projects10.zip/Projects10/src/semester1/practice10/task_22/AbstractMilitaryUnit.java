package semester1.practice10.task_22;

public abstract class AbstractMilitaryUnit {
    private final String unitName;
    protected int hp;
    public AbstractMilitaryUnit(String unitName, int hp) {
        this.unitName = unitName;
        this.hp = hp;}
    public String getUnitName() {
        return unitName;}
    public int getHp() {
        return hp;}
    public abstract int getMoveSpeed();
}
