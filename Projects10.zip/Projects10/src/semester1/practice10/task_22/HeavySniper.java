package semester1.practice10.task_22;

public class HeavySniper extends AbstractMilitaryUnit implements RangedAttacker {
    private final int attackRange;
    public HeavySniper(String unitName, int hp, int attackRange) {
        super(unitName, hp);
        this.attackRange = attackRange;}
    @Override
    public int getMoveSpeed() {
        return 2;}
    @Override
    public int getAttackRange() {
        return attackRange;}
    @Override
    public int fireShot() {
        return 85;}
}
